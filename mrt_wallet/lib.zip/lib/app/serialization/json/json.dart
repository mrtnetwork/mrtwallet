mixin JsonSerialization {
  Map<String, dynamic> toJson();
}
