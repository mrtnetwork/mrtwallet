Future<String> writeTOFile(String data, String fileName,
        {bool validate = true}) =>
    throw UnsupportedError(
        'Cannot create a instance without dart:html or dart:io.');
Future<String> bytesToFile(
        {required List<int> bytes,
        required String fileName,
        bool validate = true}) =>
    throw UnsupportedError(
        'Cannot create a instance without dart:html or dart:io.');
