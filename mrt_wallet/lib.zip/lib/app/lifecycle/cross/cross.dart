import 'package:mrt_wallet/app/models/models/typedef.dart';
import 'core.dart';

AppLifecycleListener platformLifeCycel(
        DynamicVoid onHide, DynamicVoid onFocus) =>
    throw UnsupportedError(
        'Cannot create a instance without dart:html or dart:io.');
