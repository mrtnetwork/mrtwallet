import 'package:mrt_wallet/app/websocket/core/websocket.dart';
import 'dart:io';

class WebSocketIo implements WebSocketImpl {
  WebSocketIo(this._socket, {required this.onClose});
  WebSocket _socket;

  @override
  void close() {}

  void connet() async {
    // _socket = await WebSocket.connect(url);
  }

  @override
  OnClose onClose;
}
