typedef OnClose = void Function(Object?);

abstract class WebSocketImpl {
  abstract final OnClose onClose;
  void close();
}
