abstract class AppException implements Exception {
  abstract final String message;
}
