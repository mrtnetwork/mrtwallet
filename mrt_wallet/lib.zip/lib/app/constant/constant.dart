/// app settings and related constant
export 'global/colors.dart';
export 'global/link.dart';
export 'global/paths.dart';
export 'global/storage_key.dart';
export 'global/state.dart';
export 'global/app.dart';
export 'global/rational.dart';
export 'global/serialization.dart';
