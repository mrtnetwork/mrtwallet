class APPSerializationConst {
  static const List<int> appSettingTag = [44];
  static const List<int> imageTag = [50, 1];
}
