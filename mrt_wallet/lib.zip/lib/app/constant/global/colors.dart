import 'package:flutter/material.dart';

class ColorConst {
  const ColorConst._();

  static const Color green = Colors.green;
  static const Color blue = Colors.blue;
}
