class StorageConst {
  StorageConst._();
  static const String appSetting = "setting";
  static const String setting = "app_setting";
  static const String walletStorageKey = "wallet_";
  static const String walletChecksum = "wallet_checksum";
  static const String walletNetworkKey = "network";
  static const String coingeckoCoins = "coingeckoCoins";
  static const String external = "external";
  static const String app = "app";
  static const String hdWallets = "wallets";
}
