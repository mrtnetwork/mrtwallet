class StorageKeysConst {
  StorageKeysConst._();
  static const String appMaterial = "appMaterial";
  static const String walletStorageKey = "wallet_";
  static const String walletChecksum = "wallet_checksum";
  static const String walletNetworkKey = "network";
  static const String apiProviderKey = "provider";
  static const String networkContactKey = "C";
}
