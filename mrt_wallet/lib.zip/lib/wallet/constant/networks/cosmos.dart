class CosmosConst {
  static const String osmoHrp = "osmo";
}
