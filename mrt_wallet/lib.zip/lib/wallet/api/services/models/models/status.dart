enum APIServiceStatus { active, warning, error }
