enum SocketStatus { connect, disconnect, pending }
