import 'package:flutter/material.dart';

typedef DynamicVoid = void Function();
typedef StringVoid = void Function(String);
typedef NullStringString = String? Function(String?);
typedef NullBoolVoid = void Function(bool?);
typedef FutureVoid = Future<void> Function();
typedef FutureT = Future<T?> Function<T>();
typedef VoidSetT = Function<T>(Set<T>);
typedef SuccessOrError = ValueNotifier<Widget?>?;
