import 'package:blockchain_utils/string/string.dart';
import 'package:mrt_wallet/models/api/api_provider_tracker.dart';
import 'package:mrt_wallet/provider/api/core/http_provider.dart';
import 'package:on_chain/on_chain.dart';

class EthereumRPCService with HttpProvider implements JSONRPCService {
  EthereumRPCService(this.url, this.provider,
      {this.defaultTimeOut = const Duration(seconds: 30)});
  final ApiProviderTracker provider;
  final Duration defaultTimeOut;
  @override
  Future<Map<String, dynamic>> call(ETHRequestDetails params,
      [Duration? timeout]) async {
    final response = await client
        .post(Uri.parse(url),
            headers: {'Content-Type': 'application/json'},
            body: params.toRequestBody())
        .timeout(timeout ?? defaultTimeOut);
    return StringUtils.toJson(StringUtils.decode(response.bodyBytes));
  }

  @override
  final String url;
}
