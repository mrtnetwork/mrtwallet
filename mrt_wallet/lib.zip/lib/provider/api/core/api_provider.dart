import 'package:mrt_wallet/app/core.dart';
import 'package:mrt_wallet/models/api/api_provider_tracker.dart';
import 'package:mrt_wallet/models/wallet_models/wallet_models.dart';

class ApiProviderService with Equatable {
  static const ApiProviderService blockCypher =
      ApiProviderService("BlockCypher", "https://www.blockcypher.com/");
  static const ApiProviderService mempool =
      ApiProviderService("Mempool", "https://mempool.space/");
  static const ApiProviderService xrpl =
      ApiProviderService("XRPL", "https://xrpl.org");

  final String serviceName;
  final String websiteUri;
  const ApiProviderService(this.serviceName, this.websiteUri);

  @override
  List get variabels => [serviceName, websiteUri];
}

abstract class NetworkApiProvider<T> {
  Future<void> updateBalance(T account);
  abstract final AppNetworkImpl network;
  abstract final ApiProviderTracker serviceProvider;
}
