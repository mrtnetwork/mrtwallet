import 'package:mrt_wallet/provider/api/api_provider.dart';

class TronApiProviderService extends ApiProviderService {
  const TronApiProviderService(
      {required String serviceName,
      required String websiteUri,
      required this.httpNodeUri,
      required this.solidityNodeUri})
      : super(serviceName, websiteUri);
  final String httpNodeUri;
  final String solidityNodeUri;
}
