part of 'package:mrt_wallet/provider/wallet/wallet_provider.dart';

mixin WalletStorageImpl on NativeSecureStorageImpl {
  String? _walletChecksum;
  Map<int, AppNetworkImpl> get networks;
  String _toKey(String key) {
    return "${StorageKeysConst.walletStorageKey}${_walletChecksum!}_$key";
  }

  String _toProviderKey(int networkId) {
    return "${StorageKeysConst.walletStorageKey}${_walletChecksum!}_${StorageKeysConst.apiProviderKey}_$networkId";
  }

  void _setStorageCheckSum(String v) {
    _walletChecksum = v;
  }

  Future<void> _writeWallet(String data, String checksum) async {
    await write(key: StorageKeysConst.walletStorageKey, value: data);
    await write(key: StorageKeysConst.walletChecksum, value: checksum);
  }

  Future<(String, String)?> _readWallet() async {
    final wallet = await read(key: StorageKeysConst.walletStorageKey);
    final checksum = await read(key: StorageKeysConst.walletChecksum);
    if (wallet != null && checksum != null) {
      return (wallet, checksum);
    }
    return null;
  }

  Future<(AppNetworkImpl, ApiProviderService)?> _readNetwork() async {
    try {
      final networkStr =
          await read(key: _toKey(StorageKeysConst.walletNetworkKey));

      final networkId = int.parse(networkStr!);
      final network = networks[networkId]!;
      final service = await _readNetworkProvider(network);
      return (network, service);
    } catch (e) {
      return null;
    }
  }

  Future<ApiProviderService> _readNetworkProvider(
      AppNetworkImpl networkImpl) async {
    try {
      final provider = await read(key: _toProviderKey(networkImpl.value));
      return networkImpl.getProvider(provider);
    } catch (e) {
      return networkImpl.getProvider();
    }
  }

  Future<void> _saveNetwork(AppNetworkImpl network) async {
    await write(
        key: _toKey(StorageKeysConst.walletNetworkKey),
        value: "${network.value}");
  }

  Future<void> _saveNetworkProvider(
      AppNetworkImpl network, ApiProviderService provider) async {
    provider = network.getProvider(provider.serviceName);
    final providerKey = _toProviderKey(network.value);
    await write(key: providerKey, value: provider.serviceName);
  }

  Future<void> _saveAccount(NetworkAccountCore account) async {
    final toCbor = account.toCbor().toCborHex();
    final accountStorageKey = _toKey(account.network.value.toString());
    await write(key: accountStorageKey, value: toCbor);
  }

  Future<void> _deleteAll() async {
    final keys = await readAll();
    final walletKeys = keys.keys.where(
        (element) => element.startsWith(StorageKeysConst.walletStorageKey));
    for (final i in walletKeys) {
      await delete(key: i);
    }
  }

  Future<NetworkAccountCore> _readNetworkAccout(AppNetworkImpl network) async {
    try {
      final accounts = await read(key: _toKey(network.value.toString()));
      return _toNetworkAccount(network, accounts!);
    } catch (e) {
      return _createNetworkAccount(network);
    }
  }

  Bip32NetworkAccount _toNetworkAccount(
      AppNetworkImpl network, String account) {
    switch (network.runtimeType) {
      case APPEVMNetwork:
        return Bip32NetworkAccount<BigInt, ETHAddress>.fromHex(
            account, network);
      case APPTVMNetwork:
        return Bip32NetworkAccount<BigInt, TronAddress>.fromHex(
            account, network);
      case AppXRPNetwork:
        return Bip32NetworkAccount<BigRational, XRPAddress>.fromHex(
            account, network);
      default:
        return Bip32NetworkAccount<BigInt, BitcoinAddress>.fromHex(
            account, network);
    }
  }

  Bip32NetworkAccount _createNetworkAccount(AppNetworkImpl network) {
    switch (network.runtimeType) {
      case APPEVMNetwork:
        return Bip32NetworkAccount<BigInt, ETHAddress>.setup(network);
      case APPTVMNetwork:
        return Bip32NetworkAccount<BigInt, TronAddress>.setup(network);
      case AppXRPNetwork:
        return Bip32NetworkAccount<BigRational, XRPAddress>.setup(network);
      default:
        return Bip32NetworkAccount<BigInt, BitcoinAddress>.setup(network);
    }
  }

  Future<List<NetworkAccountCore>> _readAllAccounts(
      [bool emptyAccount = false]) async {
    final List<NetworkAccountCore> accounts = [];
    for (final i in networks.values) {
      final acc = await _readNetworkAccout(i);
      if (!emptyAccount && !acc.haveAddress) continue;
      accounts.add(acc);
    }
    return List.unmodifiable(accounts);
  }
}
