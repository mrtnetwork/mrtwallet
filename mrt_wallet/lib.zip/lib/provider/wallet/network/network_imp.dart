part of 'package:my_btc/provider/wallet/wallet_provider.dart';

mixin WalletNetworkImpl on WalletCryptoImpl, NativeSecureStorageImpl {
  AppNetwork _network = AppNetwork.bitcoinTestnet;
  AppNetwork get network => _network;
  void _switchNetwork(AppNetwork newNetwork) {
    if (_network == newNetwork) return;
    _network = newNetwork;
  }

  late IAccount _account;
  bool get haveAccount => _account.haveAccount;
  IAccount get networkAccount => _account;
  Future<IAccount> _readStorageAccount() async {
    final accounts = await read(key: network.storagekey);
    if (accounts == null) return IAccount(network: network);
    return IAccount.fromHex(accounts);
  }

  Future<void> _readAccounts() async {
    _account = await _readStorageAccount();
  }
}
