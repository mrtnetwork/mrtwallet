part of 'package:mrt_wallet/provider/wallet/wallet_provider.dart';

mixin NetworkApiProviderImpl on WalletStorageImpl {
  final Map<AppNetworkImpl, NetworkApiProvider> _providers = {};

  NetworkApiProvider _buildApiProvider(AppNetworkImpl network,
      {ApiProviderService provider = ApiProviderService.mempool}) {
    if (network is APPEVMNetwork) {
      return _buildEVMProvider(network, provider);
    } else if (network is AppBitcoinNetwork) {
      return _buildBlockCypherOrMempolProvider(network, provider);
    } else if (network is AppXRPNetwork) {
      return _buildRippleProvider(network, provider);
    } else if (network is APPTVMNetwork) {
      return _buildTVMProvider(network, provider as TronApiProviderService);
    }
    throw WalletExceptionConst.incorrectNetwork;
  }

  BitcoinApiProvider _buildBlockCypherOrMempolProvider(
      AppBitcoinNetwork network, ApiProviderService provider) {
    final btcNetwork = network.coinParam.transacationNetwork;
    final serviceProvider = ApiProviderTracker(provider: provider);
    final api = provider == ApiProviderService.mempool
        ? ApiProvider.fromMempool(
            btcNetwork, BitcoinApiService(serviceProvider))
        : ApiProvider.fromBlocCypher(
            btcNetwork, BitcoinApiService(serviceProvider));
    return BitcoinApiProvider(
        provider: api, network: network, serviceProvider: serviceProvider);
  }

  EVMApiProvider _buildEVMProvider(
      APPEVMNetwork network, ApiProviderService provider) {
    final tracker = ApiProviderTracker(provider: provider);
    final emvRPC = EVMRPC(EthereumRPCService(provider.websiteUri, tracker));
    return EVMApiProvider(
        provider: emvRPC, network: network, serviceProvider: tracker);
  }

  TVMApiProvider _buildTVMProvider(
      APPTVMNetwork network, TronApiProviderService provider) {
    final httpNodeTracker = ApiProviderTracker(provider: provider);
    final solidityNodeTracker = ApiProviderTracker(provider: provider);
    final httpNode =
        TronProvider(TronHTTPService(provider.httpNodeUri, httpNodeTracker));
    final solidityNode = EVMRPC(
        EthereumRPCService(provider.solidityNodeUri, solidityNodeTracker));
    final solidityProvider = EVMApiProvider(
        provider: solidityNode,
        network: network,
        serviceProvider: solidityNodeTracker);
    return TVMApiProvider(
        provider: httpNode,
        solidityProvider: solidityProvider,
        network: network,
        serviceProvider: httpNodeTracker);
  }

  RippleApiProvider _buildRippleProvider(
      AppXRPNetwork network, ApiProviderService provider) {
    final tracker = ApiProviderTracker(provider: provider);
    XRPLRpc rpcProvider;
    switch (network.value) {
      case 30:
        rpcProvider = XRPLRpc(RippleRPCService(RPCConst.mainetUri, tracker));
        break;
      case 31:
        rpcProvider = XRPLRpc(RippleRPCService(RPCConst.testnetUri, tracker));
        break;
      default:
        rpcProvider = XRPLRpc(RippleRPCService(RPCConst.devnetUri, tracker));
        break;
    }
    return RippleApiProvider(
        provider: rpcProvider, network: network, serviceProvider: tracker);
  }

  ApiProviderTracker currentProvider(AppNetworkImpl network) =>
      _providers[network]!.serviceProvider;
  T getBitcoinNetworkApiProvider<T extends NetworkApiProvider>(
      AppBitcoinNetwork network,
      {ApiProviderService provider = ApiProviderService.mempool}) {
    if (_providers.containsKey(network) &&
        (_providers[network] as BitcoinApiProvider).serviceProvider.provider ==
            provider) {
      return (_providers[network]! as T);
    }

    return _buildApiProvider(network, provider: provider) as T;
  }

  T getNetworkApiProvider<T extends NetworkApiProvider>(
      AppNetworkImpl network) {
    _providers[network] ??= _buildApiProvider(network);
    return _providers[network]! as T;
  }

  void _setProvider(AppNetworkImpl network, {ApiProviderService? provider}) {
    if (provider != null &&
        _providers[network]?.serviceProvider.provider == provider) return;
    _providers[network] = _buildApiProvider(network,
        provider: network.getProvider(provider?.serviceName));
  }

  Future<void> _updateAccountBalance(NetworkAccountCore? account) async {
    if (account == null || !account.haveAddress) return;
    await getNetworkApiProvider(account.network).updateBalance(account.address);
    await _saveAccount(account);
  }

  Future<void> _updateAccountsBalance(NetworkAccountCore? account) async {
    if (account == null || !account.haveAddress) return;
    final provider = getNetworkApiProvider(account.network);
    for (final i in account.addresses) {
      await provider.updateBalance(i).catchError((e) {
        return null;
      });
    }
    await _saveAccount(account);
  }
}
