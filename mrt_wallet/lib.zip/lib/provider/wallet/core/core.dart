part of 'package:my_btc/provider/wallet/wallet_provider.dart';

abstract class _WalletCore extends StateController
    with
        NativeSecureStorageImpl,
        WalletCryptoImpl,
        WalletNetworkImpl,
        MasterKeyImpl {}

abstract class WalletCore extends _WalletCore with WalletStatusImpl {
  final _lock = Lock();

  Future<void> login(String password) async {
    await _lock.synchronized(() async {
      _checkLocked();
      final currentStatus = _doWork();
      try {
        print("come login!");
        await _login(password);
      } finally {
        if (walletInProgress) {
          _status = currentStatus;
        }
      }
    });
    notify();
  }

  @override
  Future<void> _initWallet() async {
    await _lock.synchronized(() async => await super._initWallet());
    notify();
  }

  @override
  void init() {
    super.init();
    _initWallet();
  }
}
