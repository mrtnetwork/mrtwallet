part of 'package:my_btc/provider/wallet/wallet_provider.dart';

// ignore: library_private_types_in_public_api
mixin WalletStatusImpl on _WalletCore {
  WalletStatus _status = WalletStatus.progress;
  WalletStatus get status => _status;
  bool get walletIsLock => _status == WalletStatus.lock;
  bool get walletIsUnlock => _status == WalletStatus.unlock;
  bool get walletInProgress => _status == WalletStatus.progress;
  bool get walletInSetup => _status == WalletStatus.setup;
  List<int>? _password;

  Future<void> _initWallet() async {
    final walletIsSetup = await read(key: WalletProviderConst.walletStorageKey);
    if (walletIsSetup != null) {
      _status = WalletStatus.lock;
    } else {
      _status == WalletStatus.setup;
    }
  }

  WalletStatus _doWork() {
    if (_status == WalletStatus.progress) {
      throw Exception();
    }
    final WalletStatus currentStataus = _status;
    _status = WalletStatus.progress;
    return currentStataus;
  }

  void _checkLocked() {
    if (_status != WalletStatus.lock) {
      throw Exception();
    }
  }

  void _unlock() {
    _status = WalletStatus.unlock;
  }

  Future<void> _login(String password) async {
    final wp = _password ?? _toWalletPassword(password);
    await _setupMasterKey(wp);
    await _readAccounts();
    _password ??= wp;
    _unlock();
  }

  Future<void> setup(GeneratedMnemonic mnemonic, String walletPassword,
      DynamicVoid onSuccess) async {
    if (!walletInSetup) return;
    final data = await forStorage(mnemonic, walletPassword);
    await write(key: WalletProviderConst.walletStorageKey, value: data);
  }
}
