part of 'package:my_btc/provider/wallet/wallet_provider.dart';

typedef SetupMnemonicCallBack = void Function(
    GeneratedMnemonic mnemonic, String walletPassword);

enum WalletStatus { setup, lock, unlock, progress }
