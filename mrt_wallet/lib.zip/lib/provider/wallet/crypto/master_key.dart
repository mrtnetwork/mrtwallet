part of 'package:my_btc/provider/wallet/wallet_provider.dart';

// ignore: library_private_types_in_public_api
mixin MasterKeyImpl on WalletCryptoImpl, NativeSecureStorageImpl {
  BipMassterKey? _massterKey;

  Future<BipMassterKey> _readMasterKey(
    List<int> password,
  ) async {
    final encrypted = await read(key: WalletProviderConst.walletStorageKey);
    final mn = await fromStroage(encrypted!, password);
    final bip32 = Bip32Slip10Secp256k1.fromSeed(mn.seed);
    final encrypt = _toGcm(password, bip32.privateKey.raw);
    return BipMassterKey(encrypt);
  }

  Future<void> _setupMasterKey(
    List<int> password,
  ) async {
    _massterKey ??= await _readMasterKey(password);
  }
}
