part of 'package:my_btc/provider/wallet/wallet_provider.dart';

mixin WalletCryptoImpl {
  List<int> _toWalletPassword(String password) {
    final List<int> key = SHA3.hash(StringUtils.encode(password));
    return List<int>.unmodifiable(
        key.sublist(0, WalletProviderConst.encryptionKeyLength));
  }

  List<int> _toGcm(List<int> key, List<int> data) {
    final GCM gcm = GCM(AES(key));
    final List<int> nonce =
        QuickCrypto.generateRandom(WalletProviderConst.encryptionNonceLength);
    final List<int> encrypt = gcm.encrypt(nonce, data);
    final toCbor = CborListValue.dynamicLength([
      CborBytesValue(nonce),
      CborBytesValue(encrypt),
    ]);
    return toCbor.encode();
  }

  List<int> _getSeed(List<int> key, BipMassterKey masaterKey) {
    final GCM gcm = GCM(AES(key));
    final toCbor = masaterKey.toCbor();
    final nonce = toCbor.value[0];
    final sealed = toCbor.value[1];
    final decrypt = gcm.decrypt(nonce, sealed);
    return decrypt!;

  }

  Future<String> forStorage(GeneratedMnemonic mnemonic, String password) async {
    final List<int> key = SHA3
        .hash(StringUtils.encode(password))
        .sublist(0, WalletProviderConst.encryptionKeyLength);
    final toCbor = _toGcm(key, mnemonic.toCbor().encode());
    return StringUtils.decode(toCbor, StringEncoding.base64);
  }

  Future<GeneratedMnemonic> fromStroage(String encrypted, List<int> key) async {
    try {
      final List<int> toCborBytes =
          StringUtils.encode(encrypted, StringEncoding.base64);
      final data = _validateStorageCbor(toCborBytes);
      if (data == null) {
        throw WalletExceptionConst.incorrectWalletData;
      }
      final decryptBytes = _decryptGcm(key, data.$2, data.$3);
      if (decryptBytes == null) {
        throw WalletExceptionConst.incorrectPassword;
      }
      final mnemonic =
          GeneratedMnemonic.fromCborBytesOrObject(bytes: decryptBytes);
      return mnemonic;
    } catch (e) {
      throw WalletExceptionConst.incorrectPassword;
    }
  }

  static List<int>? _decryptGcm(
      List<int> key, List<int> nonce, List<int> sealed) {
    final GCM gcm = GCM(AES(key));
    final decrypt = gcm.decrypt(nonce, sealed);
    if (decrypt == null) return null;
    return decrypt;
  }

  static (int, List<int>, List<int>)? _validateStorageCbor(
      List<int> toCborBytes) {
    final toCborObject = CborObject.fromCbor(toCborBytes);

    if (toCborObject is! CborListValue) return null;
    try {
      final int version = toCborObject.value[0].value;
      final List<int> nonce = toCborObject.value[1].value;

      final List<int> walletData = toCborObject.value[2].value;

      if (nonce.length != WalletProviderConst.encryptionNonceLength) {
        return null;
      }
      return (version, nonce, walletData);
    } catch (e) {
      return null;
    }
  }
}
