class CancelableExption implements Exception {
  const CancelableExption();
}
