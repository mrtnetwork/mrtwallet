class WalletException implements Exception {
  final String message;
  const WalletException(this.message);
  @override
  String toString() {
    return message;
  }
}

class WalletExceptionConst {
  static const WalletException invalidAccountDetails =
      WalletException("invalid_account_details");
  static const WalletException invalidMnemonicPassphrase =
      WalletException("invalid_passphrase");
  static const WalletException invalidMnemonic =
      WalletException("invalid_mnemonic");
  static const WalletException incorrectPassword =
      WalletException("incorrect_password");
  static const WalletException incorrectWalletData =
      WalletException("wallet_data_is_invalid");
}
