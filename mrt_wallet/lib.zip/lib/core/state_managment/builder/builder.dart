part of 'package:my_btc/core/state_managment/state_managment.dart';

typedef StateBulder<T extends StateController> = Widget Function(T controller);
typedef ControllerBuilder<T extends StateController> = T Function();

class MrtViewBuilder<T extends StateController> extends StatefulWidget {
  final StateBulder<T> builder;

  final ControllerBuilder controller;
  final String? stateId;
  final bool removable;

  const MrtViewBuilder({
    Key? key,
    required this.controller,
    required this.builder,
    this.stateId,
    this.removable = true,
  }) : super(key: key);

  @override
  MrtViewBuilderState<T> createState() => MrtViewBuilderState<T>();
}

class MrtViewBuilderState<T extends StateController>
    extends State<MrtViewBuilder<T>> {
  late final T stateController = widget.controller() as T;
  void update() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();
    WalletLogging.print("init ${stateController.runtimeType}");
    stateController._start();
    stateController.addListener(widget.stateId, update);
  }

  @override
  void dispose() {
    super.dispose();
    stateController.removeListener(widget.stateId, update);
    if (widget.removable) {
      stateController._close();
      r.remove(stateController.repositoryId);
    }
  }

  late R r;

  @override
  void didChangeDependencies() {
    r = Repository.of(context);
    r.add(context, stateController);
    super.didChangeDependencies();
  }

  @override
  void didUpdateWidget(MrtViewBuilder oldWidget) {
    super.didUpdateWidget(oldWidget as MrtViewBuilder<T>);
    if (widget.stateId != oldWidget.stateId) {
      // oldWidget.controller.removeListener(oldWidget.stateId, oldWidget._update);

      // widget.controller.addListener(widget.stateId, _update);
    }
  }

  @override
  Widget build(BuildContext context) {
    return widget.builder(stateController);
  }
}
