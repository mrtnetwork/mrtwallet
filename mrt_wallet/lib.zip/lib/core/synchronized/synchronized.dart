// MIT License

// Copyright (c) 2016, Alexandre Roux Tekartik.

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.
library synchronized;

import 'dart:async';

import 'src/basic_lock.dart';
import 'src/reentrant_lock.dart';

/// Object providing the implicit lock.
///
/// A [Lock] can be reentrant (in this case it will use a [Zone]).
///
/// non-reentrant lock is used like an aync executor with a capacity of 1.
///
/// if [timeout] is not null, it will timeout after the specified duration.
abstract class Lock {
  /// Creates a [Lock] object.
  ///
  /// if [reentrant], it uses [Zone] to allow inner [synchronized] calls.
  factory Lock({bool reentrant = false}) {
    if (reentrant == true) {
      return ReentrantLock();
    } else {
      return BasicLock();
    }
  }

  /// Executes [computation] when lock is available.
  ///
  /// Only one asynchronous block can run while the lock is retained.
  ///
  /// If [timeout] is specified, it will try to grab the lock and will not
  /// call the computation callback and throw a [TimeoutExpection] is the lock
  /// cannot be grabbed in the given duration.
  Future<T> synchronized<T>(FutureOr<T> Function() computation,
      {Duration? timeout});

  /// returns true if the lock is currently locked.
  bool get locked;

  /// for reentrant, test whether we are currently in the synchronized section.
  /// for non reentrant, it returns the [locked] status.
  bool get inLock;
}
