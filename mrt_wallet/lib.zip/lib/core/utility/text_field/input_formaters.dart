import 'package:flutter/services.dart';

class RangeTextInputFormatter extends TextInputFormatter {
  final int min;
  final int max;

  RangeTextInputFormatter({required this.min, required this.max});

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    String newString = newValue.text;
    int? enteredNumber = int.tryParse(newString);
    if (enteredNumber != null) {
      if (enteredNumber < min) {
        newString = "$min";
      } else if (enteredNumber > max) {
        newString = "$max";
      } else {
        newString = "$enteredNumber";
      }
    } else {
      newString = "$min";
    }
    return TextEditingValue(
      text: newString,
      selection: TextSelection.collapsed(offset: newString.length),
    );
  }
}
