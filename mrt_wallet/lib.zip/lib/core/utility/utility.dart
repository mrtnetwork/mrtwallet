bool isStrongPassword(String? password) {
  if (password == null) return false;
  // Use a regular expression to check for the password requirements
  const pattern = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$';
  final regExp = RegExp(pattern);
  return regExp.hasMatch(password);
}

const String _rtlChars = r'\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC';

/// Practical patterns to identify strong LTR and RTL characters,
/// respectively.  These patterns are not completely correct according to the
/// Unicode standard. They are simplified for performance and small code size.
const String _ltrChars =
    r'A-Za-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02B8\u0300-\u0590'
    r'\u0800-\u1FFF\u2C00-\uFB1C\uFDFE-\uFE6F\uFEFD-\uFFFF';

/// Determines if the first character in [text] with strong directionality is
/// RTL. If [isHtml] is true, the text is HTML or HTML-escaped.
bool startsWithRtl(String text, [bool isHtml = false]) {
  return RegExp('^[^$_ltrChars]*[$_rtlChars]').hasMatch(text);
}
