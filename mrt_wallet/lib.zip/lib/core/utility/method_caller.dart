import 'dart:async';

import 'package:my_btc/core/error/exception/cancelable.dart';

class MethodCaller {
  static Future<void> _callWithCanclable<T>(
      Future<T> Function() t, Canclable canclable) async {
    try {
      canclable.success(await t());
    } catch (e) {
      canclable.cancel(e);
    }
  }

  static Future<MethodResult<T>> call<T>(Future<T> Function() t,
      {Canclable? canclable}) async {
    try {
      Future<T> r;
      if (canclable == null) {
        r = t();
      } else {
        Completer<T> completer = Completer<T>();
        canclable.setup(<T>() {
          return completer;
        });
        _callWithCanclable(t, canclable);

        r = completer.future;
      }
      return MethodResult(await r, null);
    } on Exception catch (e) {
      return MethodResult(null, e);
    }
  }
}

class MethodResult<T> {
  MethodResult(this._result, this.exception);
  final T? _result;
  String? get error => exception?.toString();
  final Exception? exception;
  bool get hasError => error != null;
  bool get isCacel => exception is CancelableExption;
  T get result => _result!;
}

typedef CompleterResult = Completer Function();

class Canclable<T> {
  CompleterResult? _setup;
  bool cancel([Object? exception]) {
    final completer = _setup?.call();
    if (completer?.isCompleted ?? true) return false;
    completer!.completeError(exception ?? const CancelableExption());
    _setup = null;
    return false;
  }

  void success(T result) {
    final completer = _setup?.call();
    if (completer?.isCompleted ?? true) return;
    completer!.complete(result);
    _setup = null;
  }

  void setup(CompleterResult setup) {
    assert(_setup == null, "please first complete or cancel");
    _setup = setup;
  }
}
