import 'package:mrt_n/mrt_n.dart';
import 'package:mrt_n/platform_interface.dart';

mixin BaseNativeMEthod {
  static MrtNativePlatform platform = MrtPlatformInterface().mrtInterface;
}
