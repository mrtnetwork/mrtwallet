class Localization {
  static Map<String, dynamic> get languages => {
        "en": {
          "wellcome": "Welcome To Bitcoin Wallet",
          "setup": "Setup wallet",
          "use_mnemonic": "Use Existing Mnemonic",
          "generate_mnemonic": "Generate New Mnemonic",
          "e_mnemonic":
              "Enter your 12-24 word recovery phrase (mnemonic) to import your wallet",
          "g_mnemonic":
              "Generate a new 12-24 word recovery phrase (mnemonic) to create a new wallet",
          "g_mnemonic_desc":
              "Create a unique mnemonic to remember important information easily.",
          "n_of_mnemonic_words": "Number of mnemonic words",
          "count_words": "___1__ Words",
          "generate": "Generate",
          "setup_password": "Setup password",
          "p_note": "Please Note:",
          "p_note1":
              "1. Your wallet password is not stored anywhere and cannot be recovered if forgotten.",
          "p_note2":
              "2. Your mnemonic phrase is the only way to recover your wallet. Do not forget it!",
          "p_note3":
              "3. Keep your wallet password and mnemonic phrase in a safe place and never share them with anyone.",
          "p_note4":
              "4. If you lose your wallet password and mnemonic, you may permanently lose access to your funds.",
          "e_password": "Enter password",
          "c_password": "Confirm password",
          "password_desc":
              "Password should be at least 8 characters long and include a combination of letters, numbers, and special characters",
          "weak_password":
              "Password is not strong. Make sure it contains uppercase, lowercase, special character, and numbers.",
          "p_does_not_match": "Password does not match",
          "show_mnemonic_desc":
              "Please treat your mnemonic phrase with the utmost care and confidentiality. Do not share it with anyone, and ensure it remains hidden from prying eyes. Your mnemonic is the key to accessing your funds and should be kept secure at all times. Any unauthorized access may result in the loss of your assets.",
          "r_generate": "Re-generate",
          "v_mnemonic": "Verify mnemonic",
          "v_mnemonic_desc":
              "Please verify your mnemonic phrase to ensure its accuracy. Carefully enter your mnemonic words in the correct order to confirm your access to your account. This step is crucial for securing your wallet and funds.",
          "Language": "Language",
          "select_the_mnemonic": "Select the mnemonic",
          "select_mnemonic_desc":
              "Please click on the desired mnemonic in the order you viewed the mnemonic on the previous page.",
          "reset": "Reset",
          "extra_options": "Extra layer of security",
          "mn_password": "BIP32 passphrase",
          "mn_password_desc":
              "BIP32, also known as Hierarchical Deterministic Wallets, allows for the generation of a tree of keys from a single master seed. Adding a passphrase to this process creates an extra layer of security, known as a BIP32 passphrase.",
          "enable_mnemonic_password": "Enable BIP32 passphrase",
          "password_should_not_be_empty": "Password should not be empty",
          "wallet_data_is_invalid": "The wallet data is invalid",
          "incorrect_password": "Incorrect password",
          "invalid_mnemonic": "Invalid mnemonic",
          "invalid_account_details": "Invalid account details",
          "invalid_passphrase": "invalid mnemonic passphrase.",
          "close": "Close",
          "launch_the_wallet": "Launching the wallet",
          "wallet_login": "Wallet Login",
          "wallet_login_desc":
              "Welcome to the secure login portal for your cryptocurrency wallet. Please enter your credentials below to access your digital assets",
          "password": "Password",
          "unlock": "Unlock",
          "derive_bitcoin_address": "Deriving Bitcoin Addresses",
          "bip44_desc":
              "BIP44: Standard for multi-account wallets with P2PKH addresses, facilitating structured and efficient transaction management.",
          "bip49_desc":
              "BIP49: Extension of BIP44, enhancing security with P2SH nested SegWit addresses, addressing transaction malleability.",
          "bip84_desc":
              "BIP84: Introduces native SegWit (bech32) for more efficient fund storage, reducing fees and improving processing.",
          "bip86_desc":
              "BIP86: Proposes SegWit Version 1 P2TR, advancing Bitcoin's features, security, and scalability in line with community efforts.",
          "setup_bitcoin_address": "Setup bitcoin address",
          "setup_bitcoin_address_desc":
              "You have not set up any Bitcoin account. To begin setup, please click on the 'Setup Address' button.",
          "setup_address": "Setup Address",
          "choose_bitcoin_address_type": "Choose Address Type",
          "choose_bitcoin_address_type_desc":
              "Please select a Bitcoin address type to create an address.",
          "bitcoin_type_recomended":
              "We recommend creating a P2TR or P2WPKH address due to their enhanced security features and lower cost fees.",
          "standard_derivation": "Standard Derivation",
          "standard_deravation_for": "Derivation Standard for ___1__",
          "p2sh_nested_segwit": "P2SH Nested SegWit",
          "p2sh_nested_segwit_desc":
              "Enhancing Security and Transaction Handling with P2SH Nested SegWit Addresses",
          "p_level": "Purpose level",
          "c_level": "Coin level",
          "a_level": "Account level",
          "change_level": "Change level",
          "address_index": "Address index",
          "key_derivation": "Key derivation",
          "bip32_key_derivation": "BIP32 key derivation",
          "bip32_derivation_desc":
              "BIP32 levels (purpose, coin, account, change, address index) provide a hierarchical structure for generating cryptocurrency addresses, enabling deterministic wallet creation with specific attributes for organizational and security purposes.",
          "bip32_derivation_desc2":
              "When deriving key indexes, it's essential to securely record and store them. Forgetting to do so could result in potential financial losses. Always ensure that your derived key indexes are safely preserved to avoid any risks of losing access to your funds.",
          "choose_index_each_level": "Choose an index for each level.",
          "bip32_level_desc":
              "BIP32 level (purpose, coin, account, change, address index) represents the hierarchical structure used in the BIP32 standard for deriving keys."
        }
      };
}
