import 'package:flutter/material.dart';
import 'package:my_btc/models/accessibility.dart';
import 'package:my_btc/core/localization/localization.dart';

extension Translate on String {
  static get localization => Localization.languages;
  static Locale get language => Accessibility.locale;
  String get tr => localization[language.languageCode]?[this] ?? this;

  String replaceOne(String replace) {
    return replaceAll("___1__", replace);
  }
}
