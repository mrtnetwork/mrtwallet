import 'package:flutter/material.dart';
import 'package:my_btc/constant/custom_colors.dart';
import 'package:my_btc/future/pages/widgets/bottom_sheet.dart';
import 'package:my_btc/future/pages/widgets/snackbar_alert.dart';

extension QuickContextAccsess on BuildContext {
  ThemeData get theme => Theme.of(this);
  TextTheme get textTheme => theme.textTheme;
  ColorScheme get colors => theme.colorScheme;
  CustomColors get customColors => CustomColors();
  MediaQueryData get mediaQuery => MediaQuery.of(this);
  bool get hasFocus =>
      FocusScope.of(this).hasPrimaryFocus || FocusScope.of(this).hasFocus;
  void mybePop() {
    if (mounted) Navigator.maybeOf(this);
  }

  void clearFocus() {
    if (mounted) {
      FocusScope.of(this).unfocus();
    }
  }

  Future<T?> to<T>(String path, {dynamic argruments}) async {
    if (mounted) {
      return Navigator.pushNamed<T>(this, path, arguments: argruments);
    }
    return null;
  }

  void showAlert(String message) {
    SnackBar snackBar = createSnackAlert(
      message: message,
      onTap: () {
        ScaffoldMessenger.of(this).clearSnackBars();
      },
    );
    ScaffoldMessenger.of(this).showSnackBar(snackBar);
  }

  void showErrorSnackbar(Exception message) {
    SnackBar snackBar = createErrorSnackbara(
      message: message.toString(),
      onTap: () {
        ScaffoldMessenger.of(this).clearSnackBars();
      },
    );
    ScaffoldMessenger.of(this).showSnackBar(snackBar);
  }

  Future<T?> openSliverBottomSheet<T>(Widget sliver, String label,
      {double minExtent = 0.7,
      double maxExtend = 1,
      double? initialExtend}) async {
    return await showModalBottomSheet<T>(
      context: this,
      builder: (context) => AppBottomSheet(
        label: label,
        sliver: sliver,
        minExtent: minExtent,
        maxExtend: maxExtend,
        initiaalExtend: initialExtend,
      ),
      useSafeArea: true,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      elevation: 0,
    );
  }
}
