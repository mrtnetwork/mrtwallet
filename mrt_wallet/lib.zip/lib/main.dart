import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:my_btc/constant/page_path.dart';
import 'package:my_btc/future/pages/home/home_screen.dart';
import 'package:my_btc/core/state_managment/state_managment.dart';
import 'package:my_btc/future/pages/wallet/network/bitcoin/setup_addresses.dart';

import 'package:my_btc/future/pages/wallet/setup/setup_wallet.dart';
import 'package:my_btc/models/accessibility.dart';
import 'package:my_btc/future/pages/home/controller/wallet_provider.dart';

void main() {
  runApp(const MyBTC());
}

class Repository<T extends StateController> extends InheritedWidget {
  Repository({super.key, required super.child});
  final R r = R();
  static T? stateOf<T extends StateController>(
      BuildContext context, String stateId) {
    final re = context.dependOnInheritedWidgetOfExactType<Repository>();
    return re?.r.state[stateId] as T;
  }

  static R of<T extends StateController>(BuildContext context) {
    final re = context.dependOnInheritedWidgetOfExactType<Repository>();
    return re!.r;
  }

  @override
  bool updateShouldNotify(covariant InheritedWidget oldWidget) {
    return oldWidget != this;
  }
}

extension Watch on BuildContext {
  T watch<T extends StateController>(String stateId) {
    return Repository.stateOf(this, stateId)!;
  }
}

class R {
  final Map<String, StateController> state = {};
  void add<T extends StateController>(BuildContext context, T stateController) {
    state.addAll({stateController.repositoryId: stateController});
  }

  void remove(String repositoryId) {
    state.remove(repositoryId);
  }

  T? getState<T extends StateController>(String? repositoryId) =>
      state[repositoryId] as T?;
}

class MyBTC extends StatelessWidget {
  const MyBTC({super.key});
  @override
  Widget build(BuildContext context) {
    return Repository(
      child: MrtViewBuilder(
        controller: () => WalletProvider(),
        removable: false,
        builder: (_) => MaterialApp(
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: Accessibility.theme,
          locale: Accessibility.locale,
          routes: {
            PagePathConst.home: (context) => const HomeScreen(),
            PagePathConst.setup: (context) => const SetupWallet(),
            PagePathConst.setupBitcoinAddress: (context) =>
                const SetupBitcoinAddressView()
          },
          initialRoute: PagePathConst.home,
        ),
      ),
    );
  }
}
