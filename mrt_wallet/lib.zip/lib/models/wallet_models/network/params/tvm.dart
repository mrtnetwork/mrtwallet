import 'package:blockchain_utils/cbor/types/cbor_tag.dart';
import 'package:mrt_wallet/models/serializable/serializable.dart';
import 'package:mrt_wallet/models/wallet_models/network/params/network_params.dart';
import 'package:mrt_wallet/models/wallet_models/network/params/token.dart';
import 'package:mrt_wallet/provider/api/networks/tron/api_provider/tron_api_provider_service.dart';
import 'package:mrt_wallet/provider/wallet/constant/constant.dart';

class TVMNetworkParams with CborSerializable implements NetworkCoinParams {
  static const String _txIdArgs = "#txid";
  static const String _addrArgs = "#address";
  const TVMNetworkParams(
      {required this.transactionExplorer,
      required this.addressExplorer,
      required this.token,
      required this.providers,
      required this.mainnet});

  final bool mainnet;

  @override
  final String? transactionExplorer;

  @override
  final String? addressExplorer;

  @override
  int get decimal => token.decimal!;

  @override
  String get logo => token.assetLogo!;

  @override
  final Token token;

  @override
  String? getAccountExplorer(String address) {
    return addressExplorer?.replaceAll(_addrArgs, address);
  }

  @override
  String? getTransactionExplorer(String txId) {
    return transactionExplorer?.replaceAll(_txIdArgs, txId);
  }

  @override
  final List<TronApiProviderService> providers;

  @override
  CborTagValue toCbor() {
    return CborTagValue([], WalletModelCborTagsConst.evmNetworkParam);
  }
}
