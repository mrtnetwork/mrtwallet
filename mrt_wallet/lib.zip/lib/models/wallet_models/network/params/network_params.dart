import 'package:bitcoin_base/bitcoin_base.dart';
import 'package:mrt_wallet/models/wallet_models/network/network_models.dart';
import 'package:mrt_wallet/models/wallet_models/network/params/evm.dart';
import 'package:mrt_wallet/models/wallet_models/network/params/ripple.dart';
import 'package:mrt_wallet/provider/api/api_provider.dart';
import 'package:mrt_wallet/provider/api/networks/tron/api_provider/tron_api_provider_service.dart';

import 'tvm.dart';

abstract class NetworkCoinParams {
  abstract final int decimal;
  abstract final String? transactionExplorer;
  abstract final String? addressExplorer;
  abstract final String? logo;
  abstract final Token token;
  abstract final List<ApiProviderService> providers;
  String? getAccountExplorer(String address);
  String? getTransactionExplorer(String txId);
}

class NetworkCoins {
  final BitcoinParams bitcoinMainnet = const BitcoinParams(
      transactionExplorer: "https://live.blockcypher.com/btc/tx/#txid/",
      addressExplorer: "https://live.blockcypher.com/btc/address/#address/",
      transacationNetwork: BitcoinNetwork.mainnet,
      token: Token(
          name: "Bitcoin",
          symbol: "BTC",
          decimal: 8,
          assetLogo: "assets/image/btc.png"),
      providers: [ApiProviderService.mempool, ApiProviderService.blockCypher]);
  final BitcoinParams bitcoinTestnet = const BitcoinParams(
      transactionExplorer: "https://live.blockcypher.com/btc-testnet/tx/#txid/",
      addressExplorer:
          "https://live.blockcypher.com/btc-testnet/address/#address/",
      transacationNetwork: BitcoinNetwork.testnet,
      token: Token(
          name: "Bitcoin testnet",
          symbol: "tBTC",
          decimal: 8,
          assetLogo: "assets/image/btc.png"),
      providers: [ApiProviderService.mempool, ApiProviderService.blockCypher]);
  final BitcoinParams litecoinMainnet = const BitcoinParams(
      transactionExplorer: "https://live.blockcypher.com/ltc/tx/#txid/",
      addressExplorer: "https://live.blockcypher.com/ltc/address/#address/",
      transacationNetwork: LitecoinNetwork.mainnet,
      token: Token(
          name: "Litecoin",
          symbol: "LTC",
          decimal: 8,
          assetLogo: "assets/image/ltc.png"),
      providers: [ApiProviderService.blockCypher]);
  final BitcoinParams dogecoinMainnet = const BitcoinParams(
      transactionExplorer: "https://live.blockcypher.com/doge/tx/#txid/",
      addressExplorer: "https://live.blockcypher.com/doge/address/#address/",
      transacationNetwork: DogecoinNetwork.mainnet,
      token: Token(
          name: "Dogecoin",
          symbol: "Ɖ",
          decimal: 8,
          assetLogo: "assets/image/doge.png"),
      providers: [ApiProviderService.blockCypher]);
  final BitcoinParams dashMainnet = const BitcoinParams(
      transactionExplorer: "https://live.blockcypher.com/dash/tx/#txid/",
      addressExplorer: "https://live.blockcypher.com/dash/address/#address/",
      token: Token(
          name: "Dash",
          symbol: "DASH",
          decimal: 8,
          assetLogo: "assets/image/dash.png"),
      transacationNetwork: DashNetwork.mainnet,
      providers: [ApiProviderService.blockCypher]);
  final RippleNetworkParams xrpMainnet = const RippleNetworkParams(
      transactionExplorer: "https://livenet.xrpl.org/transactions/#txid",
      addressExplorer: "https://livenet.xrpl.org/accounts/#address",
      token: Token(
          name: "Ripple",
          symbol: "XRP",
          decimal: 6,
          assetLogo: "assets/image/xrp.png"),
      providers: [ApiProviderService.xrpl]);
  final RippleNetworkParams xrpTestnet = const RippleNetworkParams(
      transactionExplorer: "https://testnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://testnet.xrpl.org/accounts/#address",
      token: Token(
          name: "Ripple testnet",
          symbol: "tXRP",
          decimal: 6,
          assetLogo: "assets/image/xrp.png"),
      providers: [ApiProviderService.xrpl]);
  final RippleNetworkParams xrpDevnet = const RippleNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      token: Token(
          name: "Ripple devnet",
          symbol: "tXRP",
          decimal: 6,
          assetLogo: "assets/image/xrp.png"),
      providers: [ApiProviderService.xrpl]);

  EVMNetworkParams ethreumMainnet = EVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      chainId: BigInt.one,
      mainnet: true,
      supportEIP1559: true,
      token: const Token(
          name: "Ethereum",
          symbol: "ETH",
          decimal: 18,
          assetLogo: "assets/image/eth.png"),
      providers: [
        const ApiProviderService("llamarpc.com", "https://eth.llamarpc.com"),
      ]);
  EVMNetworkParams ethreumTestnet = EVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      chainId: BigInt.from(11155111),
      mainnet: false,
      supportEIP1559: true,
      token: const Token(
          name: "Ethereum Sepolia testnet",
          symbol: "tETH",
          decimal: 18,
          assetLogo: "assets/image/eth.png"),
      providers: [
        const ApiProviderService(
            "publicnode.com", "https://ethereum-sepolia.publicnode.com"),
      ]);
  EVMNetworkParams polygon = EVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      chainId: BigInt.from(137),
      supportEIP1559: true,
      mainnet: true,
      token: const Token(
          name: "Polygon",
          symbol: "MATIC",
          decimal: 18,
          assetLogo: "assets/image/matic.png"),
      providers: [
        const ApiProviderService(
            "publicnode.com", "https://polygon-bor.publicnode.com"),
      ]);
  EVMNetworkParams polygonTestnet = EVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      chainId: BigInt.from(80001),
      supportEIP1559: true,
      mainnet: false,
      token: const Token(
          name: "Polygon testnet",
          symbol: "tMATIC",
          decimal: 18,
          assetLogo: "assets/image/matic.png"),
      providers: [
        const ApiProviderService(
            "publicnode.com", "https://polygon-mumbai-bor.publicnode.com"),
      ]);
  EVMNetworkParams bnb = EVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      chainId: BigInt.from(56),
      supportEIP1559: false,
      mainnet: true,
      token: const Token(
          name: "BNB Smart Chain",
          symbol: "BNB",
          decimal: 18,
          assetLogo: "assets/image/bnb.png"),
      providers: [
        const ApiProviderService(
            "publicnode.com", "https://bsc.publicnode.com"),
      ]);
  EVMNetworkParams bnbTestnet = EVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      chainId: BigInt.from(97),
      mainnet: false,
      supportEIP1559: false,
      token: const Token(
          name: "BNB Smart chain testnet",
          symbol: "tBNB",
          decimal: 18,
          assetLogo: "assets/image/bnb.png"),
      providers: [
        const ApiProviderService(
            "publicnode.com", "https://bsc-testnet.publicnode.com"),
      ]);

  /// tron networks
  TVMNetworkParams tronShasta = const TVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      mainnet: false,
      token: Token(
          name: "Tron shasta testnet",
          symbol: "tTRX",
          decimal: 6,
          assetLogo: "assets/image/trx.png"),
      providers: [
        TronApiProviderService(
            serviceName: "trongrid",
            websiteUri: "https://trongrid.io",
            httpNodeUri: "https://api.shasta.trongrid.io",
            solidityNodeUri: "https://api.shasta.trongrid.io/jsonrpc"),
      ]);
  TVMNetworkParams tronNile = const TVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      mainnet: true,
      token: Token(
          name: "Tron nile testnet",
          symbol: "tTRX",
          decimal: 6,
          assetLogo: "assets/image/trx.png"),
      providers: [
        TronApiProviderService(
            serviceName: "trongrid",
            websiteUri: "https://trongrid.io",
            httpNodeUri: "https://nile.trongrid.io",
            solidityNodeUri: "https://nile.trongrid.io/jsonrpc"),
      ]);
  TVMNetworkParams tron = const TVMNetworkParams(
      transactionExplorer: "https://devnet.xrpl.org/transactions/#txid",
      addressExplorer: "https://devnet.xrpl.org/accounts/#address",
      mainnet: true,
      token: Token(
          name: "Tron",
          symbol: "TRX",
          decimal: 6,
          assetLogo: "assets/image/trx.png"),
      providers: [
        TronApiProviderService(
            serviceName: "trongrid",
            websiteUri: "https://trongrid.io",
            httpNodeUri: "https://api.trongrid.io",
            solidityNodeUri: "https://api.trongrid.io/jsonrpc"),
      ]);
}
