import 'package:blockchain_utils/cbor/types/cbor_tag.dart';
import 'package:mrt_wallet/models/serializable/serializable.dart';
import 'package:mrt_wallet/models/wallet_models/network/params/network_params.dart';
import 'package:mrt_wallet/models/wallet_models/network/params/token.dart';
import 'package:mrt_wallet/provider/api/core/api_provider.dart';
import 'package:mrt_wallet/provider/wallet/constant/constant.dart';

class EVMNetworkParams with CborSerializable implements NetworkCoinParams {
  static const String _txIdArgs = "#txid";
  static const String _addrArgs = "#address";
  const EVMNetworkParams(
      {required this.transactionExplorer,
      required this.addressExplorer,
      required this.token,
      required this.providers,
      required this.chainId,
      required this.supportEIP1559,
      required this.mainnet});

  final BigInt chainId;
  final bool supportEIP1559;
  final bool mainnet;

  @override
  final String? transactionExplorer;

  @override
  final String? addressExplorer;

  @override
  int get decimal => token.decimal!;

  @override
  String get logo => token.assetLogo!;

  @override
  final Token token;

  @override
  String? getAccountExplorer(String address) {
    return addressExplorer?.replaceAll(_addrArgs, address);
  }

  @override
  String? getTransactionExplorer(String txId) {
    return transactionExplorer?.replaceAll(_txIdArgs, txId);
  }

  @override
  final List<ApiProviderService> providers;

  @override
  CborTagValue toCbor() {
    return CborTagValue([], WalletModelCborTagsConst.evmNetworkParam);
  }
}
