import 'package:blockchain_utils/blockchain_utils.dart';

class BipMassterKey {
  BipMassterKey(this.masterKey);
  final List<int> masterKey;

  CborListValue toCbor() {
    return CborObject.fromCbor(masterKey) as CborListValue;
  }
}
