import 'package:blockchain_utils/bip/mnemonic/mnemonic.dart';
import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:my_btc/models/serializable.dart';
import 'package:my_btc/constant/wallet_provider_constant.dart';
import 'package:my_btc/core/error/exception/wallet_ex.dart';
import 'package:my_btc/core/utility/compute/compute.dart';

class GeneratedMnemonic with CborSerializable {
  GeneratedMnemonic._(this.mnemonic, this.passphrase, this.seed);
  final Mnemonic mnemonic;
  final String passphrase;
  final List<int> seed;
  static Future<GeneratedMnemonic> setup(
      Mnemonic mnemonic, String passphrase) async {
    final isValid = Bip39MnemonicValidator();
    if (!isValid.isValid(mnemonic.toStr())) {
      throw const WalletException("invalid_mnemonic");
    }

    final seed = await AppCompute.compute(
        Bip39SeedGenerator(mnemonic).generate, passphrase);

    return GeneratedMnemonic._(mnemonic, passphrase, seed);
  }

  factory GeneratedMnemonic.fromCborBytesOrObject({List<int>? bytes, CborObject? obj}) {
    try {
      final CborListValue cbor = CborSerializable.decodeCborTags(
          bytes, obj, WalletModelCborTagsConst.mnemonic);
      final String mnemonic = cbor.value[0].value;
      final String passphrase = cbor.value[1].value;
      final List<int> seed = cbor.value[2].value;
      return GeneratedMnemonic._(
          Mnemonic.fromString(mnemonic), passphrase, seed);
    } catch (e) {
      throw WalletExceptionConst.invalidMnemonic;
    }
  }

  List<String> get toList => mnemonic.toList();

  @override
  CborTagValue toCbor() {
    return CborTagValue(
        CborListValue.fixedLength(
            [mnemonic.toStr(), passphrase, CborBytesValue(seed)]),
        WalletModelCborTagsConst.mnemonic);
  }
}
