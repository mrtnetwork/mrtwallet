import 'package:my_btc/models/serializable.dart';

abstract class CryptoAddressBase with CborSerializable {
  String toAddress();
}
