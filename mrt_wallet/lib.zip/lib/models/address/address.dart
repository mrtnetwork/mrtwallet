import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:my_btc/models/address/crypto_address.dart';
import 'package:my_btc/models/serializable.dart';
import 'package:my_btc/constant/wallet_provider_constant.dart';
import 'package:my_btc/core/error/exception/wallet_ex.dart';

class CryptoAddressDetails implements CryptoAddressBase {
  const CryptoAddressDetails({required this.address, required this.balance});

  factory CryptoAddressDetails.fromCborBytesOrObject(
      {List<int>? bytes, CborObject? obj}) {
    try {
      final CborListValue cbor = CborSerializable.decodeCborTags(
          bytes, obj, WalletModelCborTagsConst.address);
      final String address = cbor.value[0];
      final BigInt balance = cbor.value[1];
      return CryptoAddressDetails(address: address, balance: balance);
    } catch (e) {
      throw WalletExceptionConst.invalidAccountDetails;
    }
  }

  final String address;
  final BigInt balance;

  @override
  CborTagValue toCbor() {
    return CborTagValue(CborListValue.fixedLength([address, balance]),
        WalletModelCborTagsConst.address);
  }

  @override
  String toCborHex() {
    return toCbor().toCborHex();
  }

  @override
  String toAddress() {
    return address;
  }
}
