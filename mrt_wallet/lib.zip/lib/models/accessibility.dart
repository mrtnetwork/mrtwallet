import 'package:flutter/material.dart';

class Accessibility {
  static final ColorScheme colorScheme = ColorScheme.fromSeed(
    seedColor: Colors.blue,
    brightness: Brightness.light,
  );
  static const TextTheme _textTheme = TextTheme();
  static final ThemeData theme = ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      textTheme: _textTheme,
      segmentedButtonTheme:
          const SegmentedButtonThemeData(selectedIcon: Icon(Icons.check_circle))
      // appBarTheme: AppBarTheme(
      //   backgroundColor: colorScheme.background,
      //   foregroundColor: colorScheme.onBackground,
      //   iconTheme: IconThemeData(color: colorScheme.primary),
      //   actionsIconTheme: IconThemeData(color: colorScheme.primary),
      // ),
      );

  static Locale locale = const Locale("en");
  // ThemeData get theme => _theme;
}
