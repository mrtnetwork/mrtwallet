import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:my_btc/models/account/bip32_account_key_index.dart';
import 'package:my_btc/models/account/bip_account_core.dart';
import 'package:my_btc/models/address/address.dart';
import 'package:my_btc/models/address/crypto_address.dart';
import 'package:my_btc/models/serializable.dart';
import 'package:my_btc/constant/wallet_provider_constant.dart';
import 'package:my_btc/core/error/exception/wallet_ex.dart';

class BitcoinAccount implements BipAccount {
  factory BitcoinAccount.fromCborHex(String hex) {
    return BitcoinAccount.fromCborBytesOrObject(
        bytes: BytesUtils.fromHexString(hex));
  }
  factory BitcoinAccount.fromCborBytesOrObject(
      {List<int>? bytes, CborObject? obj}) {
    try {
      final CborListValue cbor = CborSerializable.decodeCborTags(
          bytes, obj, WalletModelCborTagsConst.bitcoinAccoint);
      final CborTagValue cborKeyIndex = cbor.value[0].value;
      final keyIndex =
          Bip32AccountKeyIndex.fromCborBytesOrObject(obj: cborKeyIndex);
      final BipProposal proposal = BipProposal.fromValue(cbor.value[1].value);
      final String publicKey = cbor.value[2].value;
      final CryptoAddressDetails address =
          CryptoAddressDetails.fromCborBytesOrObject(obj: cbor.value[3].value);
      return BitcoinAccount(
          proposal: proposal,
          publicKey: publicKey,
          address: address,
          keyIndex: keyIndex);
    } catch (e) {
      throw WalletExceptionConst.invalidAccountDetails;
    }
  }
  BitcoinAccount(
      {required this.keyIndex,
      required this.proposal,
      required this.publicKey,
      required CryptoAddressBase address})
      : _address = address;

  @override
  final BipProposal proposal;
  @override
  final String publicKey;

  @override
  CborTagValue toCbor() {
    return CborTagValue(
        CborListValue.fixedLength(
            [keyIndex.toCbor(), proposal.value, publicKey, address.toCbor()]),
        WalletModelCborTagsConst.bitcoinAccoint);
  }

  @override
  String toCborHex() {
    return toCbor().toCborHex();
  }

  @override
  CryptoAddressBase _address;
  @override
  CryptoAddressBase get address => _address;

  @override
  final Bip32AccountKeyIndex keyIndex;
}
