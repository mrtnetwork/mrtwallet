import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:my_btc/models/account/bip_account_core.dart';
import 'package:my_btc/models/account/bitcoin/bitcoin_account.dart';
import 'package:my_btc/models/networks/network.dart';
import 'package:my_btc/models/serializable.dart';
import 'package:my_btc/constant/wallet_provider_constant.dart';
import 'package:my_btc/core/error/exception/wallet_ex.dart';

class IAccount with CborSerializable {
  IAccount({required this.network, List<BipAccount> accounts = const []})
      : accounts = List.from(accounts, growable: true);
  factory IAccount.fromHex(String cborHex) {
    return IAccount.fromCborBytesOrObject(
        bytes: BytesUtils.fromHexString(cborHex));
  }
  factory IAccount.fromCborBytesOrObject({List<int>? bytes, CborObject? obj}) {
    try {
      final CborListValue cbor = CborSerializable.decodeCborTags(
          bytes, obj, WalletModelCborTagsConst.iAccount);
      final network = AppNetwork.fromValue(cbor.value[0].value);
      final CborListValue accounts = cbor.value[1];
      final toAccounts = accounts.value
          .map((e) => BitcoinAccount.fromCborBytesOrObject(obj: e))
          .toList();
      return IAccount(network: network, accounts: toAccounts);
    } catch (e) {
      throw WalletExceptionConst.invalidAccountDetails;
    }
  }
  final AppNetwork network;
  final List<BipAccount> accounts;

  bool get haveAccount => accounts.isNotEmpty;

  @override
  CborTagValue toCbor() {
    return CborTagValue(
        CborListValue.fixedLength([
          network.value,
          CborListValue.fixedLength(accounts.map((e) => e.toCbor()).toList())
        ]),
        WalletModelCborTagsConst.iAccount);
  }
}
