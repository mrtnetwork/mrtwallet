import 'package:my_btc/models/account/bip32_account_key_index.dart';
import 'package:my_btc/models/address/crypto_address.dart';
import 'package:my_btc/models/serializable.dart';

enum BipProposal {
  bip44(44),
  bip49(49),
  bip84(84),
  bip86(86);

  final int value;
  const BipProposal(this.value);

  static BipProposal fromValue(int value) {
    return values.firstWhere((element) => element.value == value);
  }
}

abstract class BipAccount with CborSerializable {
  abstract final BipProposal proposal;
  abstract final String publicKey;
  abstract final Bip32AccountKeyIndex keyIndex;
  abstract final CryptoAddressBase address;
}
