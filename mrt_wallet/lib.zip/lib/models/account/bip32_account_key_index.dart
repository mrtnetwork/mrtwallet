import 'package:blockchain_utils/cbor/core/cbor.dart';
import 'package:blockchain_utils/cbor/types/cbor_tag.dart';
import 'package:blockchain_utils/cbor/types/list.dart';
import 'package:my_btc/constant/wallet_provider_constant.dart';
import 'package:my_btc/core/error/exception/wallet_ex.dart';
import 'package:my_btc/models/serializable.dart';

class Bip32AccountKeyIndex with CborSerializable {
  factory Bip32AccountKeyIndex.fromCborBytesOrObject(
      {List<int>? bytes, CborObject? obj}) {
    try {
      final CborListValue cbor = CborSerializable.decodeCborTags(
          bytes, obj, WalletModelCborTagsConst.accoutKeyIndex);
      final int purposeLevel = cbor.value[0].value;
      final int coinLevel = cbor.value[1].value;
      final int accountLevel = cbor.value[2].value;
      final int changeLevel = cbor.value[3].value;
      final int addressIndex = cbor.value[4].value;

      return Bip32AccountKeyIndex(
          accountLevel: accountLevel,
          addressIndex: addressIndex,
          changeLevel: changeLevel,
          purpose: purposeLevel,
          coin: coinLevel);
    } catch (e) {
      throw WalletExceptionConst.invalidAccountDetails;
    }
  }
  Bip32AccountKeyIndex(
      {required this.purpose,
      required this.coin,
      required this.accountLevel,
      required this.changeLevel,
      required this.addressIndex});
  final int purpose;
  final int coin;
  final int accountLevel;
  final int changeLevel;
  final int addressIndex;

  @override
  CborTagValue toCbor() {
    return CborTagValue(
        [purpose, coin, accountLevel, changeLevel, addressIndex],
        WalletModelCborTagsConst.accoutKeyIndex);
  }
}
