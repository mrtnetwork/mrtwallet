import 'package:my_btc/constant/wallet_provider_constant.dart';

enum AppNetwork {
  bitcoinMainnet(0),
  bitcoinTestnet(1);

  final int value;
  String get storagekey =>
      "${WalletProviderConst.walletStorageKey}accounts_$value";

  const AppNetwork(this.value);
  static AppNetwork fromValue(int value) {
    return values.firstWhere((element) => element.value == value);
  }
}
