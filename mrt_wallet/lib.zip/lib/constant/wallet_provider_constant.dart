class WalletProviderConst {
  static const int version = 1;
  static const int encryptionKeyLength = 32;
  static const int encryptionNonceLength = 12;

  static const String walletStorageKey = "wallet_";
}

class WalletModelCborTagsConst {
  static const List<int> address = [190];
  static const List<int> mnemonic = [189];
  static const List<int> iAccount = [191];
  static const List<int> bitcoinAccoint = [192];
  static const List<int> accoutKeyIndex = [193];
}
