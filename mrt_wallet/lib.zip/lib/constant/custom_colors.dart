import 'package:flutter/material.dart';

class CustomColors {
  const CustomColors._();
  static const CustomColors _instance = CustomColors._();
  factory CustomColors() => _instance;


  
  final Color green = Colors.green;
}
