class PagePathConst {
  static const String setupBitcoinAddress = "/bitcoin/setup_address";
  static const String setup = "/setup";
  static const String home = "/";
}
