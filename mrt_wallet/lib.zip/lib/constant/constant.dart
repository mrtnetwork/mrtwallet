class MyBTCConstanet {
  static const String bitcoinIcon = "assets/image/btc.png";
  static const Duration animationDuraion = Duration(milliseconds: 700);
  static const Duration milliseconds100 = Duration(milliseconds: 100);
  static const Duration oneSecoundDuration = Duration(seconds: 1);

  static const double double80 = 80;
}
