import 'package:flutter/material.dart';
import 'package:my_btc/constant/custom_colors.dart';
import 'package:my_btc/models/accessibility.dart';

class WidgetConstant {
  static const Widget height8 = SizedBox(height: 8);
  static const Widget width8 = SizedBox(width: 8);
  static const Widget height20 = SizedBox(height: 20);
  static const ScrollPhysics noScrollPhysics = NeverScrollableScrollPhysics();
  static const EdgeInsets padding5 = EdgeInsets.all(5);
  static const EdgeInsets padding10 = EdgeInsets.all(10);
  static const EdgeInsets paddingHorizontal10 =
      EdgeInsets.symmetric(horizontal: 10);
  static const EdgeInsets paddingHorizontal20 =
      EdgeInsets.symmetric(horizontal: 20);
  static const EdgeInsets padding20 = EdgeInsets.all(20);
  static const EdgeInsets paddingVertical20 =
      EdgeInsets.symmetric(vertical: 20);
  static const EdgeInsets paddingVertical10 =
      EdgeInsets.symmetric(vertical: 10);
  static const EdgeInsets paddingVertical8 = EdgeInsets.symmetric(vertical: 8);
  static final BorderRadius border8 = BorderRadius.circular(8);
  static final BorderRadius border4 = BorderRadius.circular(8);
  static const SizedBox sizedBox = SizedBox();

  static final Icon checkCircle = Icon(
    Icons.check_circle,
    color: CustomColors().green,
    size: 40,
  );
  static final Icon checkCircleLarge = Icon(
    Icons.check_circle,
    color: CustomColors().green,
    size: 80,
  );
  static final Icon errorIcon = Icon(
    Icons.error,
    color: Accessibility.colorScheme.error,
    size: 40,
  );
  static final Icon errorIconLarge = Icon(
    Icons.error,
    color: Accessibility.colorScheme.error,
    size: 80,
  );
}
