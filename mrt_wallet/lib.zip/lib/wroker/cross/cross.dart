import 'package:mrt_wallet/wroker/core/worker.dart';

IsolateCryptoWoker getCryptoWorker() => throw UnsupportedError(
    'Cannot create a instance without dart:html or dart:io.');
