import 'package:flutter/material.dart';
import 'package:my_btc/types/typedef.dart';

class FixedElevatedButton extends StatelessWidget {
  const FixedElevatedButton({
    required this.child,
    required this.onPressed,
    this.padding = EdgeInsets.zero,
    super.key,
  });
  final Widget child;
  final DynamicVoid onPressed;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: padding,
        child: ElevatedButton(onPressed: onPressed, child: child));
  }
}
