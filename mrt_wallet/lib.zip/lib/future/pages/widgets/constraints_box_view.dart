import 'package:flutter/material.dart';

class ConstraintsBoxView extends StatelessWidget {
  final Widget child;
  const ConstraintsBoxView(
      {required this.child,
      this.maxWidth = 500,
      this.maxHeight = double.infinity,
      super.key});
  final double maxWidth;
  final double maxHeight;
  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxWidth: maxWidth, maxHeight: maxHeight),
      child: child,
    );
  }
}

class SliverConstraaintsBoxView extends StatelessWidget {
  final Widget sliver;
  final EdgeInsets padding;
  const SliverConstraaintsBoxView(
      {required this.sliver,
      this.padding = EdgeInsets.zero,
      this.maxWidth = 500,
      super.key});
  final double maxWidth;

  @override
  Widget build(BuildContext context) {
    return SliverConstrainedCrossAxis(
        maxExtent: maxWidth,
        sliver: SliverPadding(
          sliver: sliver,
          padding: padding,
        ));
  }
}
