import 'package:flutter/widgets.dart';

class ViewPadding extends StatelessWidget {
  const ViewPadding({required this.child, this.padding, super.key});
  final EdgeInsets? padding;
  final Widget child;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          padding ?? const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
      child: child,
    );
  }
}

class SliverViewPadding extends StatelessWidget {
  const SliverViewPadding({required this.sliver, this.padding, super.key});
  final EdgeInsets? padding;
  final Widget sliver;
  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding:
          padding ?? const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
      sliver: sliver,
    );
  }
}
