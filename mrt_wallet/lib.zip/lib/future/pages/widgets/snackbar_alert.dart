import 'package:flutter/material.dart';
import 'package:my_btc/core/extention/string.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/types/typedef.dart';

SnackBar createSnackAlert(
    {required String message, required DynamicVoid onTap}) {
  final snackBar = SnackBar(
    backgroundColor: Colors.transparent,
    actionOverflowThreshold: 0,
    elevation: 0,
    content: GestureDetector(
      onTap: onTap,
      child: Center(
        child: SizedBox(
          height: 50,
          width: 210,
          child: Center(
            child: Card(
              elevation: 3,
              child: Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8)),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Center(
                      child: Text(
                        message,
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );
  return snackBar;
}

SnackBar createErrorSnackbara(
    {required String message, required DynamicVoid onTap}) {
  final snackBar = SnackBar(
      backgroundColor: Colors.transparent,
      action: SnackBarAction(label: "close".tr, onPressed: onTap),
      actionOverflowThreshold: 0,
      elevation: 0,
      content: Row(
        children: [
          WidgetConstant.errorIcon,
          WidgetConstant.width8,
          Text(message)
        ],
      ));
  return snackBar;
}
