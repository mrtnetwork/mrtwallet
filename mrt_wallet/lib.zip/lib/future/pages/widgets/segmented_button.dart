import 'package:flutter/material.dart';
import 'package:my_btc/core/extention/context.dart';
import 'package:my_btc/types/typedef.dart';

class AppSegmentedButton<T> extends StatelessWidget {
  const AppSegmentedButton(
      {super.key,
      required this.items,
      required this.selected,
      required this.onChangeSelected});
  final Set<T> selected;
  final Map<T, String> items;
  final VoidSetT onChangeSelected;
  @override
  Widget build(BuildContext context) {
    return SegmentedButton(
      emptySelectionAllowed: false,
      multiSelectionEnabled: false,
      segments: items.keys
          .map<ButtonSegment>((e) => ButtonSegment(
              value: e,
              label: Text(
                items[e]!,
                maxLines: 1,
                style: context.textTheme.labelSmall,
                overflow: TextOverflow.ellipsis,
              )))
          .toList(),
      selected: selected,
      onSelectionChanged: onChangeSelected,
    );
  }
}
