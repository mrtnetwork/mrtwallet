import 'package:flutter/material.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/core/extention/context.dart';

class PageTitleSubtitle extends StatelessWidget {
  const PageTitleSubtitle(
      {super.key, required this.title, required this.body, this.subtitle});
  final String title;
  final Widget body;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: context.textTheme.titleLarge,
        ),
        Padding(
          padding: WidgetConstant.padding10,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (subtitle != null)
                Text(
                  subtitle ?? "",
                  style: context.textTheme.labelLarge,
                ),
              Padding(
                padding: WidgetConstant.padding5,
                child: body,
              )
            ],
          ),
        ),
        WidgetConstant.height20
      ],
    );
  }
}
