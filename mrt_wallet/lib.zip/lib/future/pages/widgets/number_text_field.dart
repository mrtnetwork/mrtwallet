import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/core/extention/extention.dart';
import 'package:my_btc/core/synchronized/src/utils.dart';
import 'package:my_btc/core/utility/text_field/input_formaters.dart';
import 'package:my_btc/future/pages/widgets/constraints_box_view.dart';
import 'package:my_btc/types/typedef.dart';

class NumberTextField extends StatefulWidget {
  const NumberTextField({
    super.key,
    required this.label,
    required this.onChange,
    this.padding = WidgetConstant.paddingVertical8,
    this.helperText,
    this.hintText,
    this.error,
    this.validator,
    this.defaultValue,
    required this.max,
    required this.min,
  }) : assert(() {
    return false;
  }(), "min must be lower than max");
  final int min;
  final int max;
  final EdgeInsets padding;
  final String label;
  final Strsing? helperText;
  final String? hintText;
  final String? error;
  final NullStringString? validator;
  final StringVoid onChange;
  final int? defaultValue;
  @override
  State<NumberTextField> createState() => _NumberTextFieldState();
}

class _NumberTextFieldState extends State<NumberTextField> {
  bool add = false;
  bool minus = false;
  int index = 0;
  late final TextEditingController controller =
      TextEditingController(text: "${widget.min}");
  void _add(bool isAdd) {
    if (isAdd) {
      if (index >= widget.max) {
        index = widget.max;
      } else {
        index++;
      }
    } else {
      if (index <= widget.min) {
        index = widget.min;
      } else {
        index--;
      }
    }
    controller.text = index.toString();
  }

  void onTap(bool isAdd) {
    _add(isAdd);
  }

  Timer? _timer;
  void onLongPress(bool isAdd) {
    if (isAdd) {
      add = true;
    } else {
      minus = true;
    }
    _add(isAdd);
    _timer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      _add(isAdd);
    });
    setState(() {});
  }

  void onLongPressCancel() {
    add = false;
    minus = false;
    _timer?.cancel();
    _timer = null;
    setState(() {});
  }

  @override
  void dispose() {
    _timer?.cancel();
    _timer = null;
    controller.dispose();
    super.dispose();
  }

  @override
  void setState(VoidCallback fn) {
    if (!mounted) return;
    super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: widget.padding,
      child: Row(
        children: [
          SizedBox(
            width: 100,
            child: Text(
              widget.label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          WidgetConstant.width8,
          Flexible(
              child: ConstraintsBoxView(
            maxWidth: 200,
            child: TextFormField(
              textAlign: TextAlign.center,
              enableInteractiveSelection: false,
              keyboardType: TextInputType.numberWithOptions(
                  decimal: false, signed: widget.min < 0),
              controller: controller,
              validator: widget.validator,
              onChanged: widget.onChange,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                RangeTextInputFormatter(min: widget.min, max: widget.max)
              ],
              decoration: InputDecoration(
                  filled: true,
                  hintText: widget.hintText,
                  helperText: widget.helperText,
                  errorText: widget.error,
                  suffixIcon: AnimatedContainer(
                    duration: MyBTCConstanet.animationDuraion,
                    decoration: BoxDecoration(
                        color: add
                            ? context.theme.highlightColor
                            : Colors.transparent,
                        shape: BoxShape.circle),
                    child: GestureDetector(
                      onTap: () => onTap(true),
                      onLongPress: () => onLongPress(true),
                      onLongPressEnd: (e) => onLongPressCancel(),
                      child: IconButton(
                        icon: const Icon(Icons.add_box),
                        onPressed: () {
                          onTap(true);
                        },
                      ),
                    ),
                  ),
                  prefixIcon: AnimatedContainer(
                    duration: MyBTCConstanet.animationDuraion,
                    decoration: BoxDecoration(
                        color: minus
                            ? context.theme.highlightColor
                            : Colors.transparent,
                        shape: BoxShape.circle),
                    child: GestureDetector(
                      onTap: () => onTap(false),
                      onLongPress: () => onLongPress(false),
                      onLongPressEnd: (e) => onLongPressCancel(),
                      child: IconButton(
                          onPressed: () {
                            onTap(false);
                          },
                          icon: const Icon(
                              Icons.indeterminate_check_box_rounded)),
                    ),
                  )),
            ),
          )),
        ],
      ),
    );
  }
}
