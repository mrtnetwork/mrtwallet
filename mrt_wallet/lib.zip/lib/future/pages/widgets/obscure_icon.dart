import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/types/typedef.dart';

class ObscureIcon extends StatelessWidget {
  const ObscureIcon({required this.show, required this.onTap, super.key});
  final bool show;
  final DynamicVoid onTap;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(5),
        child: AnimatedSwitcher(
          duration: MyBTCConstanet.animationDuraion,
          child: show
              ? const Icon(Icons.password, key: ValueKey<bool>(false))
              : const Icon(Icons.remove_red_eye, key: ValueKey<bool>(true)),
        ),
      ),
    );
  }
}
