import 'package:flutter/material.dart';
import 'package:my_btc/core/extention/string.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';
import 'package:my_btc/types/typedef.dart';

class StupAddressDescView extends StatelessWidget {
  const StupAddressDescView(
      {super.key,
      required this.callBack,
      required this.title,
      required this.body});
  final DynamicVoid callBack;
  final String title;
  final String body;
  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PageTitleSubtitle(
            title: title,
            body: Text(body),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              FixedElevatedButton(
                  onPressed: callBack, child: Text("setup_address".tr)),
            ],
          )
        ],
      ),
    );
  }
}
