import 'package:flutter/material.dart';
import 'package:my_btc/constant/widget_constant.dart';

class ProgressWithTextView extends StatelessWidget {
  const ProgressWithTextView(
      {super.key, required this.text, this.sliver = false});
  final String text;
  final bool sliver;
  @override
  Widget build(BuildContext context) {
    if (sliver) {
      return SliverFillRemaining(
        child: _ProgressWithTextView(text: text),
      );
    }
    return _ProgressWithTextView(text: text);
  }
}

class _ProgressWithTextView extends StatelessWidget {
  const _ProgressWithTextView({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const CircularProgressIndicator(),
        WidgetConstant.height8,
        Text(text)
      ],
    );
  }
}
