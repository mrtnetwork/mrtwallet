import 'dart:async';
import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/future/pages/widgets/button.dart';
import 'package:my_btc/types/typedef.dart';

enum StreamButtonStatus {
  idle,
  success,
  error,
  progress,
  hide,
}

class StreamButton extends StatefulWidget {
  const StreamButton({
    GlobalKey<StreamButtonState>? key,
    required this.child,
    required this.onPressed,
    this.padding = EdgeInsets.zero,
    this.initialStatus = StreamButtonStatus.idle,
    this.backToIdle,
    this.hideAfterError = false,
    this.hideAfterSuccsess = false,
  }) : super(key: key);
  final StreamButtonStatus initialStatus;
  final Widget child;
  final DynamicVoid onPressed;
  final EdgeInsets padding;
  final Duration? backToIdle;
  final bool hideAfterError;
  final bool hideAfterSuccsess;

  @override
  State<StreamButton> createState() => StreamButtonState();
}

class StreamButtonState extends State<StreamButton> {
  late StreamButtonStatus _status = widget.initialStatus;
  @override
  void initState() {
    super.initState();
  }

  void _listen(StreamButtonStatus status) async {
    if (status == StreamButtonStatus.progress ||
        status == StreamButtonStatus.idle ||
        status == StreamButtonStatus.hide) return;
    if (widget.backToIdle == null) return;
    await Future.delayed(widget.backToIdle ?? Duration.zero);
    if (widget.hideAfterError && status == StreamButtonStatus.error) {
      updateStream(StreamButtonStatus.hide);
    } else if (widget.hideAfterSuccsess &&
        status == StreamButtonStatus.success) {
      updateStream(StreamButtonStatus.hide);
    } else {
      updateStream(StreamButtonStatus.idle);
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  void updateStream(StreamButtonStatus status) {
    if (!mounted) return;
    _status = status;
    _listen(status);
    setState(() {});
  }

  @override
  void setState(VoidCallback fn) {
    if (!mounted) return;

    super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: widget.padding,
      child: AnimatedSwitcher(
        duration: MyBTCConstanet.animationDuraion,
        child: _status == StreamButtonStatus.hide
            ? WidgetConstant.sizedBox
            : _status == StreamButtonStatus.success
                ? WidgetConstant.checkCircle
                : _status == StreamButtonStatus.error
                    ? WidgetConstant.errorIcon
                    : _status == StreamButtonStatus.progress
                        ? const CircularProgressIndicator()
                        : FixedElevatedButton(
                            onPressed: widget.onPressed, child: widget.child),
      ),
    );
  }
}
