import 'dart:io';

import 'package:flutter/material.dart';
import 'package:my_btc/core/utility/method_caller.dart';
import 'package:my_btc/future/pages/widgets/progress_bar/stream_bottun.dart';
import 'page_progress.dart';

export 'page_progress.dart';
export 'progress_widgets.dart';
export 'stream_bottun.dart';

extension QuickAccsessStreamButtonStateState on GlobalKey<StreamButtonState> {
  void updateStream(StreamButtonStatus status) {
    currentState?.updateStream(status);
  }

  void error() {
    currentState?.updateStream(StreamButtonStatus.error);
  }

  void success() {
    currentState?.updateStream(StreamButtonStatus.success);
  }

  void fromMethodResult(MethodResult result) {
    if (result.hasError) {
      error();
    } else {
      success();
    }
  }

  void process() {
    currentState?.updateStream(StreamButtonStatus.progress);
  }
}

extension QuickAccsessPageProgressState on GlobalKey<PageProgressState> {
  void updateStream(StreamButtonStatus status, {Widget? progressWidget}) {
    currentState?.updateStream(status, progressWidget: progressWidget);
  }
}
