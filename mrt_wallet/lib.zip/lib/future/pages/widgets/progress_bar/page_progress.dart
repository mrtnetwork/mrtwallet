import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';

typedef PageProgressStatus = StreamButtonStatus;

class PageProgress extends StatefulWidget {
  const PageProgress(
      {super.key,
      this.child,
      this.sliver,
      this.initialStatus = PageProgressStatus.idle,
      this.backToIdle,
      this.padding = EdgeInsets.zero})
      : assert(initialStatus != PageProgressStatus.hide,
            "hide does not work in page progress");
  final PageProgressStatus initialStatus;
  final Widget? child;
  final Widget? sliver;
  final Duration? backToIdle;
  final EdgeInsets padding;

  @override
  State<PageProgress> createState() => PageProgressState();
}

class PageProgressState extends State<PageProgress> {
  late PageProgressStatus _status = widget.initialStatus;
  Widget? _statusWidget;
  @override
  void initState() {
    super.initState();
  }

  void _listen(PageProgressStatus status) async {
    if (status == PageProgressStatus.progress ||
        status == PageProgressStatus.idle ||
        status == PageProgressStatus.hide) return;
    if (widget.backToIdle == null) return;
    await Future.delayed(widget.backToIdle ?? Duration.zero);
    updateStream(PageProgressStatus.idle, progressWidget: null);
  }

  @override
  void dispose() {
    super.dispose();
    _statusWidget = null;
  }

  void updateStream(PageProgressStatus status, {Widget? progressWidget}) {
    assert(status != PageProgressStatus.hide,
        "hide does not work in page progress");
    if (!mounted) return;
    _status = status;
    _statusWidget = progressWidget;
    _listen(status);
    setState(() {});
  }

  @override
  void setState(VoidCallback fn) {
    if (!mounted) return;

    super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    if (widget.sliver == null) {
      return AnimatedSwitcher(
        duration: MyBTCConstanet.animationDuraion,
        child: Padding(
          padding: widget.padding,
          key: ValueKey(_status),
          child: _status == StreamButtonStatus.success
              ? _statusWidget ?? WidgetConstant.checkCircleLarge
              : _status == StreamButtonStatus.error
                  ? _statusWidget ?? WidgetConstant.errorIconLarge
                  : _status == StreamButtonStatus.progress
                      ? _statusWidget ?? const CircularProgressIndicator()
                      : widget.child,
        ),
      );
    }
    return SliverAnimatedSwitcher(
      duration: MyBTCConstanet.animationDuraion,
      child: SliverPadding(
        padding: widget.padding,
        key: ValueKey(_status),
        sliver: _status == PageProgressStatus.idle
            ? widget.sliver
            : _SliverProgressView(
                status: _status,
                sliver: _statusWidget,
              ),
      ),
    );
  }
}

class _SliverProgressView extends StatelessWidget {
  const _SliverProgressView({required this.status, this.sliver});
  final PageProgressStatus status;
  final Widget? sliver;

  @override
  Widget build(BuildContext context) {
    return sliver ??
        SliverFillRemaining(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              status == PageProgressStatus.success
                  ? WidgetConstant.checkCircleLarge
                  : status == PageProgressStatus.error
                      ? WidgetConstant.errorIconLarge
                      : const CircularProgressIndicator()
            ],
          ),
        );
  }
}
