import 'package:flutter/material.dart';
import 'package:my_btc/core/dev/logging.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';

import 'package:my_btc/provider/wallet/wallet_provider.dart';

class WalletProvider extends WalletCore {
  WalletProvider() {
    WalletLogging.print("WalletProvider constructor created!");
  }

  final GlobalKey<PageProgressState> pageStatusHandler =
      GlobalKey<PageProgressState>();

  @override
  String get repositoryId => "main";
 
}
