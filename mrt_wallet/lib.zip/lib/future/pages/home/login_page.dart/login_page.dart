import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/core/extention/string.dart';
import 'package:my_btc/core/utility/method_caller.dart';
import 'package:my_btc/core/utility/utility.dart';
import 'package:my_btc/future/pages/home/controller/wallet_provider.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';
import 'package:my_btc/main.dart';

class WalletLoginPageView extends StatefulWidget {
  const WalletLoginPageView({super.key});

  @override
  State<WalletLoginPageView> createState() => _WalletLoginPageViewState();
}

class _WalletLoginPageViewState extends State<WalletLoginPageView> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final GlobalKey<StreamButtonState> buttonKey = GlobalKey<StreamButtonState>();
  String? _error;
  String password = "";
  void onChange(String v) {
    password = v;
    resetError();
  }

  void resetError() {
    if (_error != null) {
      setState(() {
        _error = null;
      });
    }
  }

  void unlock() async {
    if (!(formKey.currentState?.validate() ?? false)) return;
    buttonKey.process();

    final login = await MethodCaller.call(() {
      final provider = context.watch<WalletProvider>("main");
      return provider.login(password);
    });
    buttonKey.fromMethodResult(login);
    _error = login.error;
    if (context.mounted) {
      setState(() {});
    }
  }

  @override
  void setState(VoidCallback fn) {
    if (!context.mounted) return;
    super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Form(
        key: formKey,
        child: Column(
          children: [
            PageTitleSubtitle(
                title: "wallet_login".tr, body: Text("wallet_login_desc".tr)),
            const CircleAssetsImgaeView(MyBTCConstanet.bitcoinIcon),
            WidgetConstant.height20,
            AppTextField(
              obscureText: true,
              onChanged: onChange,
              label: "password".tr,
              disableContextMenu: true,
              error: _error,
              validator: (v) {
                if (isStrongPassword(v)) {
                  return null;
                }
                return "password_desc".tr;
              },
            ),
            StreamButton(
              padding: WidgetConstant.paddingVertical20,
              onPressed: unlock,
              backToIdle: MyBTCConstanet.oneSecoundDuration,
              key: buttonKey,
              child: Text("unlock".tr),
            ),
          ],
        ),
      ),
    );
  }
}
