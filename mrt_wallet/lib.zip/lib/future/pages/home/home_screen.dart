import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/constant/page_path.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/core/dev/logging.dart';
import 'package:my_btc/core/extention/context.dart';
import 'package:my_btc/core/extention/string.dart';
import 'package:my_btc/future/pages/home/login_page.dart/login_page.dart';
import 'package:my_btc/future/pages/wallet/network/bitcoin/address_page.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';
import 'package:my_btc/core/state_managment/state_managment.dart';
import 'package:my_btc/main.dart';
import 'package:my_btc/future/pages/home/controller/wallet_provider.dart';
import 'package:my_btc/models/networks/network.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MrtViewBuilder<WalletProvider>(
      removable: false,
      controller: () => context.watch<WalletProvider>("main"),
      builder: (model) => Material(
        color: context.colors.primary,
        key: model.pageStatusHandler,
        child: SafeArea(
          child: Scaffold(
            resizeToAvoidBottomInset: true,
            body: UnfocusableChild(
              child: PageProgress(
                child: CustomScrollView(
                  slivers: [
                    SliverConstraaintsBoxView(
                      padding: WidgetConstant.padding20,
                      sliver: SliverAnimatedSwitcher(
                        duration: MyBTCConstanet.animationDuraion,
                        child: model.walletIsLock
                            ? const WalletLoginPageView()
                            : model.walletIsUnlock
                                ? _NetworkPages(network: model.network)
                                : SliverFillRemaining(
                                    child: ConstraintsBoxView(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        const CircleAssetsImgaeView(
                                            MyBTCConstanet.bitcoinIcon),
                                        WidgetConstant.height8,
                                        Text(
                                          "wellcome".tr,
                                          style: context.textTheme.titleLarge,
                                        ),
                                        WidgetConstant.height20,
                                        AppListTile(
                                          title: Text("use_mnemonic".tr),
                                          subtitle: Text("e_mnemonic".tr),
                                          trailing:
                                              const Icon(Icons.arrow_forward),
                                          onTap: () async {
                                            context.showAlert("hafaar");
                                          },
                                        ),
                                        WidgetConstant.height8,
                                        AppListTile(
                                          title: Text("generate_mnemonic".tr),
                                          subtitle: Text("g_mnemonic".tr),
                                          trailing:
                                              const Icon(Icons.arrow_forward),
                                          onTap: () {
                                            context.to(PagePathConst.setup);
                                          },
                                        ),
                                      ],
                                    ),
                                  )),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NetworkPages extends StatelessWidget {
  const _NetworkPages({super.key, required this.network});
  final AppNetwork network;
  @override
  Widget build(BuildContext context) {
    print("here $network");
    switch (network) {
      case AppNetwork.bitcoinMainnet:
        return const BitcoinAddressView();
      case AppNetwork.bitcoinTestnet:
        return const BitcoinAddressView();
      default:
        return Text("jafar");
    }
  }
}
