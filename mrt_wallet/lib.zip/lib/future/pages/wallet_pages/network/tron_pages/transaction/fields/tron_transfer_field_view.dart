import 'package:flutter/material.dart';
import 'package:mrt_wallet/app/core.dart';
import 'package:mrt_wallet/future/pages/wallet_pages/network/tron_pages/transaction/fields/tron_transaction_fields.dart';
import 'package:mrt_wallet/models/wallet_models/network/network_models.dart';
import 'package:mrt_wallet/models/wallet_models/network/transaction/tron/transaction_validator/transfer/transfer.dart';
import 'package:mrt_wallet/models/wallet_models/token/networks/tron/trc10_token.dart';
import 'package:mrt_wallet/models/wallet_models/token/networks/tron/trc20_token.dart';

class TronTransferTransactionView extends StatelessWidget {
  const TronTransferTransactionView({super.key});

  @override
  Widget build(BuildContext context) {
    final Token? token = context.getNullArgruments();
    final TronTRC20Token? trc20token = context.getNullArgruments();
    final TronTRC10Token? trc10Token = context.getNullArgruments();
    return TronTransactionFieldsView(
        field: LiveTransactionValidator(
            validator: TronTransferValidator(
                token: token ?? trc20token?.token ?? trc10Token!.token,
                trc20Token: trc20token,
                trc10Token: trc10Token)));
  }
}
