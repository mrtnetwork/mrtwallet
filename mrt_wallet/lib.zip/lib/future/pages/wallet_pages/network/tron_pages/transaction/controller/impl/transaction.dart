import 'package:flutter/material.dart';
import 'package:mrt_wallet/app/state_managment/state_managment.dart';
import 'package:mrt_wallet/future/pages/start_page/home.dart';
import 'package:mrt_wallet/future/widgets/custom_widgets.dart';
import 'package:mrt_wallet/models/wallet_models/account/account.dart';
import 'package:mrt_wallet/models/wallet_models/address/address.dart';
import 'package:mrt_wallet/models/wallet_models/network/core/network.dart';
import 'package:mrt_wallet/models/wallet_models/network/custom/tron/tron_fee.dart';
import 'package:mrt_wallet/models/wallet_models/network/transaction/tron/transaction_validator/core/tron_field_validator.dart';
import 'package:mrt_wallet/provider/api/networks/tron/tron.dart';
import 'package:on_chain/tron/provider/models/chain_parameters.dart';

abstract class TronTransactionImpl extends StateController {
  TronTransactionImpl(
      {required this.walletProvider,
      required this.account,
      required this.network,
      required this.address,
      required this.apiProvider});
  TronChainParameters get tronChainParameters;
  TronTransactionValidator get field;
  final WalletProvider walletProvider;
  final Bip32NetworkAccount account;
  final APPTVMNetwork network;
  final TVMApiProvider apiProvider;
  final ITronAddress address;
  ITronAddress get owner => address;
  String? get memo;
  TronFee? get consumedFee;
  final GlobalKey<PageProgressState> progressKey = GlobalKey<PageProgressState>(
      debugLabel: "progressKey_EthTransactionImpl");
}
