import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/core/extention/extention.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/future/pages/home/controller/wallet_provider.dart';
import 'package:my_btc/future/pages/wallet/setup/setup.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';
import 'package:my_btc/main.dart';
import 'package:my_btc/core/error/exception/wallet_ex.dart';

class MnemonicExtraOptionView extends StatefulWidget {
  const MnemonicExtraOptionView({super.key});

  @override
  State<MnemonicExtraOptionView> createState() =>
      _MnemonicExtraOptionViewState();
}

class _MnemonicExtraOptionViewState extends State<MnemonicExtraOptionView> {
  bool usePassword = false;
  final GlobalKey<FormState> form = GlobalKey<FormState>();
  final FocusNode nextFocus = FocusNode();

  String password = "";

  void onChange(bool? v) {
    usePassword = v ?? usePassword;
    password = "";
    setState(() {});
  }

  void onChangedText(String v) {
    password = v;
  }

  @override
  void setState(VoidCallback fn) {
    if (!mounted) return;
    super.setState(fn);
  }

  @override
  void dispose() {
    nextFocus.dispose();
    super.dispose();
  }

  final GlobalKey<PageProgressState> _pageProgressController = GlobalKey();

  void setup() async {
    if (!(form.currentState?.validate() ?? false)) return;
    _pageProgressController.currentState
        ?.updateStream(StreamButtonStatus.progress,
            progressWidget: ProgressWithTextView(
              text: "launch_the_wallet".tr,
              sliver: true,
            ));
    try {
      final model = context.watch<SetupWalletController>("setup_wallet");
      final walletProvider = context.watch<WalletProvider>("main");
      final mnemonic = await model.setup(usePassword ? password : null);
      await walletProvider.setup(mnemonic.$1, mnemonic.$2, () {});
      _pageProgressController.currentState
          ?.updateStream(StreamButtonStatus.success);
      return;
      // ignore: empty_catches
    } on WalletException catch (e) {
      if (context.mounted) {
        context.showErrorSnackbar(e);
      }
    }
    _pageProgressController.currentState
        ?.updateStream(StreamButtonStatus.error);
  }

  @override
  Widget build(BuildContext context) {
    return PageProgress(
      key: _pageProgressController,
      backToIdle: const Duration(seconds: 1),
      sliver: SliverToBoxAdapter(
        child: Form(
          key: form,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              PageTitleSubtitle(
                title: "extra_options".tr,
                body: Text("mn_password_desc".tr),
                subtitle: "mn_password".tr,
              ),
              AppCheckListTile(
                title: Text("enable_mnemonic_password".tr),
                value: usePassword,
                onChanged: onChange,
              ),
              AnimatedSize(
                duration: MyBTCConstanet.animationDuraion,
                alignment: Alignment.centerLeft,
                child: !usePassword
                    ? WidgetConstant.sizedBox
                    : Padding(
                        padding: WidgetConstant.paddingHorizontal20,
                        child: Column(
                          children: [
                            AppTextField(
                              label: "mn_password".tr,
                              obscureText: true,
                              nextFocus: nextFocus,
                              disableContextMenu: true,
                              onChanged: onChangedText,
                              validator: (p0) {
                                if (!usePassword) return null;
                                if (p0?.isEmpty ?? true) {
                                  return "password_should_not_be_empty".tr;
                                }
                                return null;
                              },
                            ),
                            AppTextField(
                              label: "c_password".tr,
                              obscureText: true,
                              disableContextMenu: true,
                              focusNode: nextFocus,
                              validator: (p0) {
                                if (!usePassword) return null;
                                if (password == p0) return null;
                                return "p_does_not_match".tr;
                              },
                            ),
                          ],
                        ),
                      ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  FixedElevatedButton(
                    padding: WidgetConstant.paddingVertical20,
                    onPressed: setup,
                    child: Text("setup".tr),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
