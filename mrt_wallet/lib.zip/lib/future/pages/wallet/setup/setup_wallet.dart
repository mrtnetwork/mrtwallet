import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/core/extention/context.dart';
import 'package:my_btc/core/extention/string.dart';
import 'package:my_btc/future/pages/wallet/setup/setup.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';
import 'package:my_btc/core/state_managment/state_managment.dart';


class SetupWallet extends StatelessWidget {
  const SetupWallet({super.key});

  @override
  Widget build(BuildContext context) {
    return MrtViewBuilder<SetupWalletController>(
      stateId: "setup_wallet",
      controller: () => SetupWalletController(),
      builder: (model) {
        return WillPopScope(
          onWillPop: model.backButton,
          child: Material(
            color: context.theme.primaryColor,
            child: SafeArea(
              child: Scaffold(
                body: UnfocusableChild(
                  child: CustomScrollView(
                    slivers: [
                      SliverAppBar(
                        title: Text("setup".tr),
                        pinned: true,
                      ),
                      SliverViewPadding(
                        sliver: SliverConstraaintsBoxView(
                          sliver: SliverAnimatedSwitcher(
                            duration: MyBTCConstanet.animationDuraion,
                            child: model.inExtraOption
                                ? const MnemonicExtraOptionView()
                                : model.inPassword
                                    ? const SetupWalletPassword()
                                    : model.inConfirm
                                        ? VerifyMnemonicView(
                                            mnemonic:
                                                model.mnemonic!.toList())
                                        : const GenerateMnemonicView(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
