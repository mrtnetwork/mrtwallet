import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/core/extention/context.dart';

class MnemonicView extends StatelessWidget {
  const MnemonicView({super.key, required this.mnemonic});
  final List<String> mnemonic;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(borderRadius: WidgetConstant.border8),
      child: Padding(
        padding: WidgetConstant.padding10,
        child: GridView.count(
          shrinkWrap: true,
          childAspectRatio: 2.0,
          physics: WidgetConstant.noScrollPhysics,
          crossAxisCount: 3,
          addAutomaticKeepAlives: false,
          addRepaintBoundaries: false,
          addSemanticIndexes: false,
          mainAxisSpacing: 1,
          crossAxisSpacing: 1,
          children: List.generate(
              mnemonic.length,
              (index) => AnimatedSwitcher(
                    duration: MyBTCConstanet.animationDuraion,
                    child: Stack(
                      key: ValueKey<String>(mnemonic[index]),
                      fit: StackFit.expand,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              borderRadius: WidgetConstant.border4,
                              color: context.colors.secondaryContainer),
                          child: Center(
                            child: Text(
                              mnemonic[index],
                              style: context.textTheme.bodyMedium
                                  ?.copyWith(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topCenter,
                          child: Row(
                            children: [
                              Padding(
                                  padding: WidgetConstant.padding5,
                                  child: Badge.count(count: index + 1)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )),
        ),
      ),
    );
  }
}
