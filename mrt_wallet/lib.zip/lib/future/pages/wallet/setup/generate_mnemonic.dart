import 'package:blockchain_utils/bip/bip/bip39/bip39_mnemonic.dart';
import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/core/extention/extention.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/future/pages/wallet/setup/setup.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';
import 'package:my_btc/core/state_managment/state_managment.dart';
import 'package:my_btc/main.dart';

class GenerateMnemonicView extends StatelessWidget {
  const GenerateMnemonicView({super.key});
  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: MrtViewBuilder<SetupWalletController>(
        stateId: "generaate_mnemonic",
        controller: () => context.watch<SetupWalletController>("setup_wallet"),
        removable: false,
        builder: (model) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              PageTitleSubtitle(
                  title: "generate_mnemonic".tr,
                  body: Text("show_mnemonic_desc".tr),
                  subtitle: 'p_note'.tr),
              DropdownButtonFormField<int>(
                decoration: InputDecoration(
                  label: Text("n_of_mnemonic_words".tr),
                ),
                value: model.mnemonicWord,
                items: [12, 15, 18, 21, 24].map((count) {
                  return DropdownMenuItem<int>(
                      value: count,
                      child:
                          Text("count_words".tr.replaceOne(count.toString())));
                }).toList(),
                onChanged: model.updateMnemonicCount,
              ),
              WidgetConstant.height8,
              DropdownButtonFormField<Bip39Languages>(
                value: model.language,
                decoration: InputDecoration(
                  label: Text("Language".tr),
                ),
                items: Bip39Languages.values.map((language) {
                  return DropdownMenuItem<Bip39Languages>(
                    value: language,
                    child: Text(language.name),
                  );
                }).toList(),
                onChanged: model.updateLanguage,
              ),
              WidgetConstant.height20,
              AnimatedSize(
                duration: MyBTCConstanet.animationDuraion,
                alignment: Alignment.center,
                child: AnimatedSwitcher(
                  duration: MyBTCConstanet.animationDuraion,
                  child: model.mnemonic == null
                      ? const SizedBox()
                      : SizedBox(
                          width: context.mediaQuery.size.width,
                          key: ValueKey<int?>(model.mnemonic?.hashCode),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              MnemonicView(mnemonic: model.mnemonic!.toList()),
                              WidgetConstant.height20,
                            ],
                          ),
                        ),
                ),
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FixedElevatedButton(
                          onPressed: () {
                            if (model.mnemonic == null) {
                              model.generate();
                            } else {
                              model.toConfirm();
                            }
                          },
                          child: model.mnemonic == null
                              ? Text("generate".tr)
                              : Text("v_mnemonic".tr)),
                    ],
                  ),
                  if (model.mnemonic != null)
                    TextButton(
                        onPressed: () {
                          model.generate();
                        },
                        child: Text("r_generate".tr))
                ],
              )
            ],
          );
        },
      ),
    );
  }
}
