import 'package:blockchain_utils/compare/compare.dart';
import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/core/extention/context.dart';
import 'package:my_btc/core/extention/string.dart';
import 'package:my_btc/future/pages/wallet/setup/setup.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';

import 'package:my_btc/main.dart';
import 'package:my_btc/models/wallet/selected_mnemonic.dart';

class VerifyMnemonicView extends StatefulWidget {
  const VerifyMnemonicView({required this.mnemonic, super.key});
  final List<String> mnemonic;
  @override
  State<VerifyMnemonicView> createState() => _VerifyMnemonicViewState();
}

class _VerifyMnemonicViewState extends State<VerifyMnemonicView> {
  late final List<String> shuffleMnemonic = List<String>.from(widget.mnemonic)
    ..shuffle();

  // late final List<SelectedMnemonic> inSelectMnemonic =
  //     List<SelectedMnemonic>.filled(
  //         widget.mnemonic.length, SelectedMnemonic.notSelected());
  late final List<SelectedMnemonic> inSelectMnemonic = List.generate(
      widget.mnemonic.length,
      (index) => SelectedMnemonic.select(index, widget.mnemonic[index]));

  bool equal = false;

  void isEqual() {
    equal = iterableIsEqual(selectedMnemonic, widget.mnemonic);
  }

  List<String> get selectedMnemonic =>
      inSelectMnemonic.map((e) => e.word ?? "").toList();
  final List<int> selectedIndex = [];
  void tap(int index) {
    try {
      if (selectedIndex.contains(index)) {
        final selcetIndex =
            inSelectMnemonic.indexWhere((element) => element.index == index);
        inSelectMnemonic[selcetIndex] = SelectedMnemonic.notSelected();
        selectedIndex.remove(index);

        return;
      }
      selectedIndex.add(index);
      final word = shuffleMnemonic.elementAt(index);
      final emptyIndex =
          inSelectMnemonic.indexWhere((element) => element.index == null);
      inSelectMnemonic[emptyIndex] = SelectedMnemonic.select(index, word);
    } finally {
      setState(() {
        isEqual();
      });
    }
  }

  @override
  void setState(VoidCallback fn) {
    if (!mounted) return;
    super.setState(fn);
  }

  void clear() {
    for (int i = 0; i < inSelectMnemonic.length; i++) {
      inSelectMnemonic[i] = SelectedMnemonic.notSelected();
    }
    selectedIndex.clear();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    isEqual();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PageTitleSubtitle(
            title: "v_mnemonic".tr,
            subtitle: 'p_note'.tr,
            body: Text("v_mnemonic_desc".tr),
          ),
          MnemonicView(mnemonic: selectedMnemonic),
          WidgetConstant.height20,
          AnimatedSwitcher(
            duration: MyBTCConstanet.animationDuraion,
            child: equal
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        children: [
                          Icon(
                            Icons.check_circle,
                            size: MyBTCConstanet.double80,
                            color: context.customColors.green,
                          ),
                          FixedElevatedButton(
                              padding: WidgetConstant.paddingVertical20,
                              onPressed: () {
                                context
                                    .watch<SetupWalletController>(
                                        "setup_wallet")
                                    .toExtra(selectedMnemonic);
                              },
                              child: Text("extra_options".tr)),
                        ],
                      ),
                    ],
                  )
                : Column(
                    children: [
                      PageTitleSubtitle(
                          title: "select_the_mnemonic".tr,
                          body: Text("select_mnemonic_desc".tr)),
                      Container(
                        decoration:
                            BoxDecoration(borderRadius: WidgetConstant.border8),
                        child: Padding(
                          padding: WidgetConstant.padding10,
                          child: Wrap(
                            crossAxisAlignment: WrapCrossAlignment.center,
                            alignment: WrapAlignment.center,
                            spacing: 8.0,
                            children:
                                List.generate(shuffleMnemonic.length, (index) {
                              return Card(
                                elevation:
                                    selectedIndex.contains(index) ? 0 : 3,
                                shape: RoundedRectangleBorder(
                                    borderRadius: WidgetConstant.border4,
                                    side: const BorderSide(width: 1)),
                                child: InkWell(
                                  onTap: () {
                                    tap(index);
                                  },
                                  child: Padding(
                                      padding: WidgetConstant.padding10,
                                      child: Text(shuffleMnemonic[index])),
                                ),
                              );
                            }),
                          ),
                        ),
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          FixedElevatedButton(
                              onPressed: clear, child: Text("reset".tr))
                        ],
                      )
                    ],
                  ),
          )
        ],
      ),
    );
  }
}
