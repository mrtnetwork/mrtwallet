import 'package:flutter/material.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/core/extention/string.dart';
import 'package:my_btc/future/pages/wallet/setup/controller/controller.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';
import 'package:my_btc/main.dart';
import 'package:my_btc/core/utility/utility.dart';

class SetupWalletPassword extends StatefulWidget {
  const SetupWalletPassword({super.key});

  @override
  State<SetupWalletPassword> createState() => _SetupWalletPasswordState();
}

class _SetupWalletPasswordState extends State<SetupWalletPassword> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final FocusNode nextFocus = FocusNode();
  String password = "";
  void onChangePassword(String v) {
    password = v;
  }

  bool _obscureText = true;

  void toggleObscure() {
    _obscureText = !_obscureText;
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    nextFocus.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final model = context.watch<SetupWalletController>("setup_wallet");
    return SliverToBoxAdapter(
      child: Form(
        key: formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PageTitleSubtitle(
              title: "setup_password".tr,
              subtitle: 'p_note'.tr,
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("p_note1".tr),
                  Text("p_note2".tr),
                  Text("p_note3".tr),
                  Text("p_note4".tr),
                ],
              ),
            ),
            AppTextField(
              obscureText: _obscureText,
              onChanged: onChangePassword,
              keyboardType: TextInputType.visiblePassword,
              textInputAction: TextInputAction.go,
              disableContextMenu: true,
              nextFocus: nextFocus,
              validator: (value) {
                if (isStrongPassword(value)) {
                  return null;
                }
                return "weak_password".tr;
              },
              label: "e_password".tr,
              helperText: "password_desc".tr,
            ),
            AppTextField(
              obscureText: _obscureText,
              keyboardType: TextInputType.visiblePassword,
              textInputAction: TextInputAction.done,
              focusNode: nextFocus,
              disableContextMenu: true,
              validator: (value) {
                if (value != password) {
                  return "p_does_not_match".tr;
                }
                return null;
              },
              label: "c_password".tr,
            ),
            WidgetConstant.height20,
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FixedElevatedButton(
                    child: Text("setup_password".tr),
                    onPressed: () {
                      if (formKey.currentState?.validate() ?? false) {
                        model.setPassword(password);
                      }
                    }),
              ],
            )
          ],
        ),
      ),
    );
  }
}
