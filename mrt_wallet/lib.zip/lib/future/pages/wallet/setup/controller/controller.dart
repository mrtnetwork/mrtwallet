import 'package:blockchain_utils/bip/bip/bip39/bip39.dart';
import 'package:blockchain_utils/bip/mnemonic/mnemonic.dart';
import 'package:blockchain_utils/compare/compare.dart';
import 'package:my_btc/core/state_managment/state_managment.dart';
import 'package:my_btc/models/wallet/mnemonic.dart';
import 'package:my_btc/core/error/exception/wallet_ex.dart';
import 'package:my_btc/core/utility/utility.dart';

enum SetupWalletPage { password, mnemonic, confirm, extraOption }

class SetupWalletController extends StateController {
  Mnemonic? _mnemonic;
  Mnemonic? get mnemonic => _mnemonic;
  int _mnemoicWord = 12;
  int get mnemonicWord => _mnemoicWord;

  Bip39Languages _language = Bip39Languages.english;
  Bip39Languages get language => _language;

  SetupWalletPage _page = SetupWalletPage.password;
  SetupWalletPage get page => _page;
  bool get inPassword => _page == SetupWalletPage.password;
  bool get inMnemonic => _page == SetupWalletPage.mnemonic;
  bool get inConfirm => _page == SetupWalletPage.confirm;
  bool get inExtraOption => _page == SetupWalletPage.extraOption;

  Future<bool> backButton() async {
    switch (page) {
      case SetupWalletPage.extraOption:
        _page = SetupWalletPage.confirm;
        break;
      case SetupWalletPage.confirm:
        _page = SetupWalletPage.mnemonic;
        _mnemonic = null;
        break;
      case SetupWalletPage.mnemonic:
        _page = SetupWalletPage.password;
        break;
      default:
        return true;
    }
    notify();
    return false;
  }

  String _password = "";

  void setPassword(String password) {
    if (isStrongPassword(password)) {
      _password = password;
      _page = SetupWalletPage.mnemonic;

      notify();
    }
  }

  void updateMnemonicCount(int? value) {
    if (value == null) return;
    _mnemoicWord = value;
    _mnemonic = null;
    notify();
  }

  void updateLanguage(Bip39Languages? language) {
    if (language == null) return;
    _language = language;
    _mnemonic = null;
    notify();
  }

  void generate() {
    final wNum = Bip39WordsNum.values
        .firstWhere((element) => element.value == _mnemoicWord);
    final mne = Bip39MnemonicGenerator(language);
    _mnemonic = mne.fromWordsNumber(wNum);
    notify();
  }

  void toConfirm() {
    if (_mnemonic == null) return;
    _page = SetupWalletPage.confirm;
    notify();
  }

  void toExtra(List<String> selectedMnemonic) {
    if (!iterableIsEqual(selectedMnemonic, _mnemonic?.toList())) {
      return;
    }
    _page = SetupWalletPage.extraOption;
    notify();
  }

  Future<(GeneratedMnemonic, String)> setup(String? passphrase) async {
    if (passphrase?.isEmpty ?? false) {
      throw WalletExceptionConst.invalidMnemonicPassphrase;
    }
    final generate = await GeneratedMnemonic.setup(mnemonic!, passphrase ?? "");
    return (generate, _password);
  }

  @override
  String get repositoryId => "setup_wallet";
}
