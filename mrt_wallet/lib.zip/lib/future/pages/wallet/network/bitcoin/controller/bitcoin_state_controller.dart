import 'package:my_btc/core/state_managment/state_managment.dart';

class BitcoinStateController extends StateController {
  @override
  String get repositoryId => "bitcoin";
}
