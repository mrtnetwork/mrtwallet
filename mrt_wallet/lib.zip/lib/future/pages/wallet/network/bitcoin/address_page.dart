import 'package:flutter/material.dart';
import 'package:my_btc/constant/page_path.dart';
import 'package:my_btc/core/extention/context.dart';
import 'package:my_btc/core/extention/string.dart';
import 'package:my_btc/core/state_managment/state_managment.dart';
import 'package:my_btc/future/pages/home/controller/wallet_provider.dart';
import 'package:my_btc/future/pages/wallet/network/bitcoin/controller/bitcoin_state_controller.dart';
import 'package:my_btc/future/pages/widgets/wallet_custom_widget/setup_address.dart';
import 'package:my_btc/main.dart';

class BitcoinAddressView extends StatelessWidget {
  const BitcoinAddressView({super.key});

  @override
  Widget build(BuildContext context) {
    final wallet = context.watch<WalletProvider>("main");
    return MrtViewBuilder(
      controller: () => BitcoinStateController(),
      builder: (controller) {
        if (!wallet.haveAccount) {
          return StupAddressDescView(
            body: "setup_bitcoin_address_desc".tr,
            title: "setup_bitcoin_address".tr,
            callBack: () {
              context.to(PagePathConst.setupBitcoinAddress,
                  argruments: wallet.networkAccount);
            },
          );
        }
        return const SliverToBoxAdapter();
      },
    );
  }
}
