import 'package:blockchain_utils/bip/bip/bip32/bip32_key_data.dart';
import 'package:flutter/material.dart';
import 'package:my_btc/constant/constant.dart';
import 'package:my_btc/constant/widget_constant.dart';
import 'package:my_btc/core/extention/extention.dart';

import 'package:my_btc/future/pages/home/controller/wallet_provider.dart';
import 'package:my_btc/future/pages/widgets/custom_widgets.dart';
import 'package:my_btc/main.dart';
import 'package:my_btc/models/account/iaccount.dart';
import 'package:my_btc/types/typedef.dart';

class SetupBitcoinAddressView extends StatefulWidget {
  const SetupBitcoinAddressView({super.key});

  @override
  State<SetupBitcoinAddressView> createState() =>
      _SetupBitcoinAddressViewState();
}

class _SetupBitcoinAddressViewState extends State<SetupBitcoinAddressView> {
  late final IAccount account;
  bool inited = false;
  void _setupIAccount() {
    if (inited) return;
    inited = true;
    account = context.watch<WalletProvider>("main").networkAccount;
  }

  Set<int> selected = {3};
  void onChangeSelected<T>(Set<T> value) {
    selected = value.cast<int>();
    segwitP2sh = false;
    derivationStandard = true;
    setState(() {});
  }

  bool derivationStandard = true;
  bool segwitP2sh = false;
  void onChangeDerivation(bool? val, DynamicVoid onFalse) {
    if (val == null) return;
    if (derivationStandard) {
      onFalse();
      return;
    }
    derivationStandard = val ?? derivationStandard;
    setState(() {});
  }

  void onChageSegwit(bool? val) {
    segwitP2sh = val ?? segwitP2sh;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    _setupIAccount();
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: context.colors.primary,
      child: SafeArea(
        child: Scaffold(
          body: UnfocusableChild(
            child: CustomScrollView(
              slivers: [
                SliverAppBar(
                  title: Text("setup_address".tr),
                  pinned: true,
                ),
                SliverConstraaintsBoxView(
                  padding: WidgetConstant.padding20,
                  sliver: SliverToBoxAdapter(
                    child: Column(
                      children: [
                        PageTitleSubtitle(
                            title: "derive_bitcoin_address".tr,
                            body: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("bip44_desc".tr),
                                WidgetConstant.height8,
                                Text("bip49_desc".tr),
                                WidgetConstant.height8,
                                Text("bip84_desc".tr),
                                WidgetConstant.height8,
                                Text("bip86_desc".tr)
                              ],
                            )),
                        PageTitleSubtitle(
                            title: "choose_bitcoin_address_type".tr,
                            body: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("choose_bitcoin_address_type_desc".tr),
                                Text("bitcoin_type_recomended".tr)
                              ],
                            )),
                        AppSegmentedButton<int>(
                            items: const {
                              0: "P2PKH",
                              1: "P2SH",
                              2: "P2WSH",
                              3: "P2TR"
                            },
                            onChangeSelected: onChangeSelected,
                            selected: selected),
                        WidgetConstant.height20,
                        _AddressTypeOPtion(
                          select: selected.first,
                          deriveStandard: derivationStandard,
                          segwitP2sh: segwitP2sh,
                          onChangeDeravation: (p0) {
                            onChangeDerivation(
                              p0,
                              () {
                                context.openSliverBottomSheet(
                                    const _AddressTypePathSetup(),
                                    "key_derivation".tr);
                              },
                            );
                          },
                          onChangeP2shSegwit: onChageSegwit,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AddressTypeOPtion extends StatelessWidget {
  const _AddressTypeOPtion(
      {required this.select,
      required this.deriveStandard,
      required this.onChangeDeravation,
      required this.segwitP2sh,
      required this.onChangeP2shSegwit});
  final int select;
  final bool deriveStandard;
  final NullBoolVoid onChangeDeravation;
  final bool segwitP2sh;
  final NullBoolVoid onChangeP2shSegwit;
  static String _getBipName(int select) {
    switch (select) {
      case 0:
        return "BIP44";
      case 1:
        return "BIP49";
      case 2:
        return "BIP84";

      default:
        return "BIP86";
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: MyBTCConstanet.animationDuraion,
      child: Column(
        key: ValueKey<int>(select),
        children: [
          AppSwitchListTile(
            value: deriveStandard,
            onChanged: onChangeDeravation,
            title: Text("standard_derivation".tr),
            subtitle: Text(
                "standard_deravation_for".tr.replaceOne(_getBipName(select))),
          ),
          if (select == 1)
            AppSwitchListTile(
              onChanged: onChangeP2shSegwit,
              value: segwitP2sh,
              title: Text("p2sh_nested_segwit".tr),
              subtitle: Text("p2sh_nested_segwit_desc".tr),
            ),
        ],
      ),
    );
  }
}

class _AddressTypePathSetup extends StatelessWidget {
  const _AddressTypePathSetup({super.key});

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: Column(
        children: [
          PageTitleSubtitle(
              title: "bip32_key_derivation".tr,
              subtitle: "p_note".tr,
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("bip32_derivation_desc".tr),
                  WidgetConstant.height8,
                  Text("bip32_derivation_desc2".tr)
                ],
              )),
          PageTitleSubtitle(
              title: "choose_index_each_level".tr,
              body: Text("bip32_level_desc".tr)),
          NumberTextField(
            label: "p_level".tr,
            max: Bip32KeyDataConst.keyIndexMaxVal,
            min: 0,
            onChange: (p0) {},
          ),
          NumberTextField(
            label: "c_level".tr,
            max: Bip32KeyDataConst.keyIndexMaxVal,
            min: 0,
            onChange: (p0) {},
          ),
          NumberTextField(
            label: "a_level".tr,
            max: Bip32KesyDataConst.keyIndexMaxVal,
            min: 0,
            onChange: (p0) {},
          ),
          NumberTextField(
            label: "change_level".tr,
            max: Bip32KeyDataConst.keyIndexMaxVal,
            min: 0,
            onChange: (p0) {},
          ),
          NumberTextField(
            label: "address_index".tr,
            max: Bip32KeyDataConst.keyIndexMaxVal,
            min: 0,
            onChange: (p0) {},
          ),
        ],
      ),
    );
  }
}
