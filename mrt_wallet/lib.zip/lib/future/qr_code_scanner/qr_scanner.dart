export 'state/barcode_scanner.dart';
