import 'package:flutter/material.dart';
import 'package:mrt_wallet/future/qr_code_scanner/state/barcode_scanner.dart';

State<BarcodeScannerView> barcodeScannerState() => throw UnimplementedError(
    "Cannot create a instance without dart:html or dart:io.");
